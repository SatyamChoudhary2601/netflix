<?php if($_SESSION['username']!='Guest') { ?>
<!-- <section class="eight-img-sec page-hide text-center">
    <div class="right-nav-images ">
                        
                   
   <div class="thumbnailgallery">
    <div class="showrooms1 clearfix"> <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-1.jpg" alt=""></a>
 <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-2.jpg" alt=""></a>
    <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-3.jpg" alt=""></a>
    <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-4.jpg" alt=""></a>
    <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-5.jpg" alt=""></a>
    <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-7.jpg" alt=""></a>
    <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-7.jpg" alt=""></a>
    <a href="" class="logo1"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-8.jpg" alt=""></a>
      
        
    

    </div>
    
</div>

</div>

</section> -->
<section class="eight-img-sec">
    <ul>
    <li> <div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-1.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">24</span><span class="online">online</span></div></div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-2.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">24</span><span class="online">online</span></div></div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-3.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">26</span><span class="online">online</span></div></div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-4.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">30</span><span class="online">online</span></div></div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-5.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">29</span><span class="online">online</span></div</div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-6.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">24</span><span class="online">online</span></div</div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-7.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">26</span><span class="online">online</span></div></div></li>
    <li><div class='photo-slider logo'><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-8.jpg" alt=""><div class='photo-status3'>Julit,&nbsp;<span class="my_age">24</span><span class="online">online</span></div></div></li>
    </ul>
</section>

<section class="copy-right">
    <div class="container">
        <div class="row">
            <div class="content-width">
            <div class="footer_menu">
                    <ul class="footer_tabs">
                        <li class="i1"><a href="https://dev.mynewbride.com/privacy/" onclick="window.open('https://dev.mynewbride.com/privacy/','_self')" target="_blank"><span>Privacy Policy</span></a></li>
                        <li class="i1"><a href="https://dev.mynewbride.com/page/Sexual-Offender" onclick="window.open('https://dev.mynewbride.com/page/Sexual-Offender','_self')" target="_blank"><span>Sexual Offender &amp; Dating Violence Policy</span></a></li>
                        <li class="i2"><a href="https://dev.mynewbride.com/page/IMBRA-POLICY" onclick="window.open('https://dev.mynewbride.com/page/IMBRA-POLICY','_self')" target="_blank"><span>IMBRA Rules and Policies</span></a></li>
                        <li class="i3"><a href="https://dev.mynewbride.com/page/STORY" onclick="window.open('https://dev.mynewbride.com/page/STORY','_self')" target="_blank"><span>See Our Story</span></a></li>
                        <li class="i4"><a href="https://dev.mynewbride.com/page/AboutUs" onclick="window.open('https://dev.mynewbride.com/page/AboutUs','_self')" target="_blank"><span>About Us</span></a></li>
                        <li class="i5"><a href="https://dev.mynewbride.com/page/TERMS" onclick="window.open('https://dev.mynewbride.com/page/TERMS','_self')" target="_blank"><span>Terms and Conditions</span></a></li>
                        <li class="i6"><a href="https://dev.mynewbride.com/page/DISCLAIMER" onclick="window.open('https://dev.mynewbride.com/page/DISCLAIMER','_self')" target="_blank"><span>Disclaimer</span></a></li>
                        <li class="i7"><a href="https://dev.mynewbride.com/page/COOKIES" onclick="window.open('https://dev.mynewbride.com/page/COOKIES','_self')" target="_blank"><span>Cookie Policy</span></a></li>
                        <li class="i8"><a href="https://dev.mynewbride.com/invite/" onclick="window.open('https://dev.mynewbride.com/invite/','_self')" target="_blank"><span>Tell a Friend</span></a></li>
                        <li class="i9"><a href="https://dev.mynewbride.com/faq/" onclick="window.open('https://dev.mynewbride.com/faq/','_self')" target="_blank"><span>FAQ</span></a></li>
                    </ul>
                </div> </div><br>
                
            <div class="col-md-12">
                <p>© 2020 - All Rights Reserved Worldwide</p>
            </div>
        </div>
    </div>
</section>    
    
</div>    
    

</body>
</html>
<script>
$(document).ready(function(e){
        var pageURL = $(location).attr("href");
        
    if(pageURL.indexOf("page") > -1)
    {
        $('.page-hide').hide();
        $('.search_bar').hide();
        $('.slider-form').hide();
         $('.what-happening-world').hide();
        if(pageURL=="https://dev.mynewbride.com/page/prifile-section")
        {
            $('.what-happening-world-page').show();
        }
        

    }
	//$('#quick-search').hide();
	//$('#main').hide();container
   // $('.container').hide();
   /*setInterval(function () {
       var last = $('.logo1').last().css({opacity: '0', width: '20px'});
    last.prependTo('.showrooms1');
    last.animate({opacity: '1', width: '152px'});
    },3000);
*/});	
</script>
<?php } else {
	//check
if($_SERVER['REQUEST_URI']!='/' && $page!='index'){

	?>

<div class="clear"></div>

</div>

 <!-- Modal -->
<?php if($page != 'index'){
    
    echo include_script_files(); 
    
} ?>
<!--<script type="text/javascript" src="inc/templates/v17red/bxslider2/jquery.bxslider.js"></script>
<script type="text/javascript" src="inc/templates/v17red/bxslider2/jquery.bxslider.min.js"></script>
<link href="inc/templates/v17red/bxslider2/jquery.bxslider.css" rel="stylesheet" type="text/css" /> -->
<!--<script>
jQuery('.bxslider').bxSlider({
  auto: true,
  autoControls: true,
  captions: true
});
</script>
<script>
jQuery('.bxslider2').bxSlider({
  auto: true,
  autoControls: true,
  captions: true
});
</script>-->
<!-- Invitation Part Start -->


<!-- Invitation Part Start -->

<?php 
## SIdebar Users Online
funcDisplaySidebarOnline();

## Display Footer Area
funcLayoutUserFooter($FOOTER_MENU_BAR,$FOOTER_MENU_TIMER,$BANNER_ARRAY,$page);
?>

</div>

<!-- END PAGE MAIN BACKGROUND -->

</div> <!-- End of wide_wrapper -->




<script language="javascript" type="text/javascript">
    var jQuery = jQuery.noConflict();
    jQuery('form[name="cssform"]').prepend('<div class="loding_img" ><img src="/inc/templates/<?=D_TEMP?>/images/flightloader.gif"></div>');
    jQuery('iframe#PreviewFrame').hide();
jQuery(window).load(function() {
    
    jQuery('iframe#PreviewFrame').contents().find('#fullpage').addClass('iframe_cont_body'); 
    jQuery('iframe#PreviewFrame').contents().find('.collapsable.list').addClass('closed');
    jQuery('iframe#PreviewFrame').contents().find('.i-count.chats.chat-hide').addClass('chat-show');
    jQuery('iframe#PreviewFrame').contents().find('.value.minimize').addClass('disabled');
    jQuery('iframe#PreviewFrame').contents().find('.value.maximize').removeClass('disabled');
    jQuery('iframe#PreviewFrame').css('height','650px');
    jQuery(".loding_img").fadeOut();
    jQuery('iframe#PreviewFrame').fadeIn(10);
});
</script>

</body>


</html>
<?php } } ?>
<script>
	$(document).ready(function(){
		$('a').click(function(){
			if($(this).closest("div").hasClass('macting-malink')){
				window.location.href = $(this).attr('href');
			}
			
			if($(this).find("span").text()=='Tell a Friend'){
				window.location.href = $(this).attr('href');
			}	
			if($(this).closest("div").hasClass('gi-omakig-inner')){
				window.location.href = $(this).attr('href');
			}
			if($(this).closest("div").hasClass('new_link_a')){
				window.location.href = $(this).attr('href');
			}
			if($(this).find("span").text()=='MNB Concierge Services'){
				window.location.href = $(this).attr('href');
			}
			if($(this).closest("li").hasClass('hd-link')){
				window.location.href = $(this).attr('href');
			}
		});
		
		$('.main-ul-slider a').click(function(){
			window.location.href = $(this).attr('href');
		});					
		
		setTimeout(function(){
			$('#copyright_bar').find('a').text('© 2020 - All Rights Reserved WorldWide');
			
			if(window.location.href.indexOf('mnb-services') > 0){
				$('.search_bar').removeClass('service');
				$('#search_modal_myBtn').hide();							
			}			
			
		},1000);
		
		if(window.location.href.indexOf('invite') > 0){
			$('.send-here-flower').hide();
			$('.what-happening-world').hide();
			$('.what-happening-world').hide();
			$('.search_bar').hide();							
			$('.slider-form').hide();
			
			setTimeout(function(){
				$('.bd_padding_20').css('border','1');
			});
		}
	});
</script>
<script>
    //console.log("reached javascript");
    var children = document.getElementById('copyright_bar');
    children.innerHTML= '<b><a href="https://dev.mynewbride.com/">© 2020 - All Rights Reserved WorldWide</a></b>';
    //console.log(children.innerHTML);
</script>
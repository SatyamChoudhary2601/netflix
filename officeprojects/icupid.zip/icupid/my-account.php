<style type="text/css">input.in-name {
        padding: 0;
        width: 25%;
        font-size: 12px;
    }

    button.btn.btn-primary.bew_pri {
        padding: 8px 18px 8px 18px;
        font-size: 12px;
        font-weight: bold;
        background-color: #003366;
    }

    li.selected {
        background: #ffc202!important;
        border: #ffc202!important;
    }
    ul.form .CapBody li input.MainBtn {
        background: #ffc202!important;
    }
    .CapBody {
        border: none;
    }
</style>
<div class="user" id="eMeeting">
    <div class="header account_tabs">
        <ul>
            <li class="selected mn-add" style="font-size:18px;"><a href="javascript:void(0)"><span>My Account</span></a></li>
        </ul>

        <div class="ClearAll">&nbsp;</div>
    </div>
</div>

<div id="step_1" style="display:visible;">
    <div class="CapBody bd_padding_20">
        <form id="tell_friend">
            <ul>
                <li><label>Name:</label> <input class="input" id="C1" name="name" placeholder="Full Name" size="40" type="text" value="" /></li>
                <li><label>Country:</label> <select class="input" id="C6" name="country">
                        <option value="">Choose Country</option>
                    </select></li>
                <li><label>State:</label> <select class="input" id="C7" name="state" >
                        <option value="">Choose City</option>
                    </select></li>
                <li><label>City:</label> <input class="input" id="C8" name="city" placeholder=" City" size="40" type="text" value="" /></li>
                <li><label>Address:</label> <input class="input" id="C2" name="address" placeholder=" Address" size="40" type="text" value="" /></li>
                <li><label>Zip/Postal Code:</label> <input class="input" id="C9" name="code" placeholder=" Zip/Postal Code" size="40" type="text" value="" /></li>
                <li><label>Phone No:</label> <input class="input" id="C3" name="phone" placeholder=" Phone No" size="40" type="text" value="" /></li>
                <li><label>Old Password:</label> <input class="input" id="C4" name="oldpass" placeholder=" Old Password" size="40" type="password" value="" /></li>
                <li><label>New Password:</label> <input class="input" id="C5" name="newpass" placeholder=" New Password" size="40" type="password" value="" /></li>
                <li><label>Confirm Password:</label> <input class="input" id="C5" name="cpass" placeholder=" Confirm Password" size="40" type="password" value="" /></li>
                <li><label>Email:</label> <input class="input" id="C10" name="email" placeholder=" Email" size="40" type="text" value="" /></li>
                <li><input class="MainBtn" type="button" value="Submit" /></li>
            </ul>
        </form>
    </div>

    <ul>
    </ul>
</div>




//SEE our story


<p style="text-align: center;"><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">See Our Story</span></b></span></span></span></p>

<p align="center" style="text-align:center"><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">Why Did We Start MyNewBride?</span></b></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">Are you exhausted spending countless hours on dating websites trying to find &#39;the one&#39;? </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">Don&#39;t give up! We&#39;re unlike the rest.</span></b></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Yes, e get it; it&#39;s the same line, different dating sites. <b><u>Trust us and verify</u></b>; this service has been founded on ethics, principles, and morals revolve around the core of what we do and believe. </span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">To explain this, let&#39;s rewind to 2018.</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">During 2018, several sincere individuals sat around the dinner table and shared their dating frustrations about the traditional yet &#39;leading&#39; dating websites of our time. Unexpectedly on that evening, the ethical men and women at that dinner table found a commonality between them all. There has to be Truth, Honesty, and Integrity built into this system for us to succeed. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">First, the majority of these females had found themselves subjected to many undesirable males who regularly displayed offensive behavior and were only using such websites to satisfy their perverted sexual desires. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Many of these females were exposed to uncensored images, and the males often wanted to use them for money. Most often, it was revealed that this behavior was being displayed to many ladies at the same time.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">The women at this dinner table all admitted to reporting the profiles of these cretins, and specifically, they had informed the websites about the indecent behavior they had become a victim too. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Alarmingly, the majority of these complaints got dismissed by these websites. The truth is, the website owners were more motivated about the money coming in from these men, as opposed to promoting ethics on their websites.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">It gets worse. </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Not only were these complaints dismissed, but however many times, these females had also found themselves blocked by the admin and told not to make a fuss. They were allowing these males to go about showcasing their continued indecent behavior.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">It&#39;s not always the men, though, right?</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">To be clear, we know there were decent hearted males on these websites also. Because similar scenarios occurred with our male founders, who admitted they were using such services to find a kind and honest woman.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">At first, the men experienced many &#39;pinch me&#39; moments, counting themselves lucky, convinced they were conversing with a gorgeous model. However, when it came to meet them, they&#39;d discovered they&#39;d been catfished. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Meaning the people didn&#39;t show up for the meet, or even worse, they were told of Eastern European men who were speaking or instead texting for these women! &nbsp;Even more surprisingly, many of the masterminds behind these fraudulent profiles were employees of the dating websites! The irony of the situation became apparent when, on many occasions, it was discovered that these ladies who had posted jobs on their profile were consistently on the site almost 24 hours daily. Doctors, Nurses, Lawyers, Veterinarians, who were never at work. No matter what time of the day that you signed on, they were there to greet you.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Most of these ladies wholeheartedly admitted to not being verified, when pressed, even though their profile had a verification symbol. When the truth was, the staff or local agents supposedly working in Europe or other Baltic countries just attached the verification symbol to their profile to give the impression that all of their ladies on the site were, in fact, verified. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">Maybe you&#39;ve been a victim to this too? </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Ladies and gentlemen, that evening, the foundations were formed for new ethical service with the resolve to do better for real lonely men and women around the world. Which today, we know as MyNewBride LLC. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">What is My New Bride LLC?</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">MyNewBride is a sophisticated international marriage network offering a new and improved service for genuine lonely people who want to meet their potential life partner. Unlike others in the industry, we guarantee users&#39; authenticity by using state-of-the-art verification systems that are on display at the point of entry into our website.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">Before becoming a member, every individual has to present their identification card, driver&#39;s license, country passport, and an instant selfie before gaining access. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">After all, we care about your safety.</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">To serve our real purpose, we charge our gentlemen a nominal monthly and affordable service fee (in comparison to what they were accustomed to paying monthly, without the accompanying professional services). For ladies, it is entirely free. We also grant the privilege to our members to submit free letters, send messages, and feely enjoy OnDemand Video Talk so they can clearly see who they are talking to and potentially making futures plans with.</span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">Watch this space, though, our services are always evolving to strengthen your romantic connections. </span></b></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><span lang="EN" style="color:#0e101a">To MyNewBride, this service is more than a business transaction; it&#39;s essential to us that you find your life partner, your soul mate, or your spouse, whatever your preference is. Whoever you are, regardless of gender, caste, race, religion, or nationality, we welcome you to meet your future better half with My New Bride. </span></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif"><b><span lang="EN" style="color:#0e101a">If you succeed, we achieve. </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif">&nbsp;</span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span style="font-family:Arial,sans-serif">&nbsp;</span></span></span></p>

<p>&nbsp;</p>





////


<style type="text/css">p{
        font-family: Raleway,sans-serif;
    }
    span {
        font-family: Raleway,sans-serif;
    }
    .CapBody.bd_padding_20 {
        color: #053c70;
        font-size: 20px;
        font-family: Raleway,sans-serif;
    }
</style>
<p style="text-align: center;margin: 0px 0 13px 0px;font-size: 32px;color: #053c70;"><strong>See Our Story</strong></p>

<p align="center" class="CapBody.bd_padding_20" style="text-align:center"><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">Why Did We Start MyNewBride?</span></b></span></span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">Are you exhausted spending countless hours on dating websites trying to find &#39;the one&#39;? </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">Don&#39;t give up! We&#39;re unlike the rest.</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Yes, e get it; it&#39;s the same line, different dating sites. <b><u>Trust us and verify</u></b>; this service has been founded on ethics, principles, and morals revolve around the core of what we do and believe. </span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">To explain this, let&#39;s rewind to 2018.</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">During 2018, several sincere individuals sat around the dinner table and shared their dating frustrations about the traditional yet &#39;leading&#39; dating websites of our time. Unexpectedly on that evening, the ethical men and women at that dinner table found a commonality between them all. There has to be Truth, Honesty, and Integrity built into this system for us to succeed. </span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">First, the majority of these females had found themselves subjected to many undesirable males who regularly displayed offensive behavior and were only using such websites to satisfy their perverted sexual desires. </span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Many of these females were exposed to uncensored images, and the males often wanted to use them for money. Most often, it was revealed that this behavior was being displayed to many ladies at the same time.</span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">The women at this dinner table all admitted to reporting the profiles of these cretins, and specifically, they had informed the websites about the indecent behavior they had become a victim too. </span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Alarmingly, the majority of these complaints got dismissed by these websites. The truth is, the website owners were more motivated about the money coming in from these men, as opposed to promoting ethics on their websites.</span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">It gets worse. </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Not only were these complaints dismissed, but however many times, these females had also found themselves blocked by the admin and told not to make a fuss. They were allowing these males to go about showcasing their continued indecent behavior.</span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">It&#39;s not always the men, though, right?</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">To be clear, we know there were decent hearted males on these websites also. Because similar scenarios occurred with our male founders, who admitted they were using such services to find a kind and honest woman.</span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">At first, the men experienced many &#39;pinch me&#39; moments, counting themselves lucky, convinced they were conversing with a gorgeous model. However, when it came to meet them, they&#39;d discovered they&#39;d been catfished. </span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Meaning the people didn&#39;t show up for the meet, or even worse, they were told of Eastern European men who were speaking or instead texting for these women! &nbsp;Even more surprisingly, many of the masterminds behind these fraudulent profiles were employees of the dating websites! The irony of the situation became apparent when, on many occasions, it was discovered that these ladies who had posted jobs on their profile were consistently on the site almost 24 hours daily. Doctors, Nurses, Lawyers, Veterinarians, who were never at work. No matter what time of the day that you signed on, they were there to greet you.</span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Most of these ladies wholeheartedly admitted to not being verified, when pressed, even though their profile had a verification symbol. When the truth was, the staff or local agents supposedly working in Europe or other Baltic countries just attached the verification symbol to their profile to give the impression that all of their ladies on the site were, in fact, verified. </span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">Maybe you&#39;ve been a victim to this too? </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Ladies and gentlemen, that evening, the foundations were formed for new ethical service with the resolve to do better for real lonely men and women around the world. Which today, we know as MyNewBride LLC. </span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">What is My New Bride LLC?</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">MyNewBride is a sophisticated international marriage network offering a new and improved service for genuine lonely people who want to meet their potential life partner. Unlike others in the industry, we guarantee users&#39; authenticity by using state-of-the-art verification systems that are on display at the point of entry into our website.</span></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">Before becoming a member, every individual has to present their identification card, driver&#39;s license, country passport, and an instant selfie before gaining access. </span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">After all, we care about your safety.</span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">To serve our real purpose, we charge our gentlemen a nominal monthly and affordable service fee (in comparison to what they were accustomed to paying monthly, without the accompanying professional services). For ladies, it is entirely free. We also grant the privilege to our members to submit free letters, send messages, and feely enjoy OnDemand Video Talk so they can clearly see who they are talking to and potentially making futures plans with.</span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">Watch this space, though, our services are always evolving to strengthen your romantic connections. </span></b></span></span></span></p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><span lang="EN" style="color:#0e101a">To MyNewBride, this service is more than a business transaction; it&#39;s essential to us that you find your life partner, your soul mate, or your spouse, whatever your preference is. Whoever you are, regardless of gender, caste, race, religion, or nationality, we welcome you to meet your future better half with My New Bride. </span></span></span></span></p>
<p>&nbsp;</p>

<p><span style="font-size:11pt"><span style="line-height:115%"><span><b><span lang="EN" style="color:#0e101a">If you succeed, we achieve. </span></b></span></span></span></p>
<p><span style="font-size:11pt"><span style="line-height:115%"><span>&nbsp;</span></span></span></p>


<!--<!--Section: Contact v.2-->
<section class="mb-4" style="margin-right: 1%;margin-left: 1%;">

    <!--Section heading-->
    <h2 class="h1-responsive font-weight-bold text-center my-4">Contact us</h2>
    <!--Section description-->
    <p class="text-center w-responsive mx-auto mb-5">Do you have any questions? Please do not hesitate to contact us directly. Our team will come back to you within
        a matter of hours to help you.</p>

    <div class="row">

        <!--Grid column-->
        <div class="col-md-12 mb-md-0 mb-5">
            <form id="contact-form" name="contact-form" action="mail.php" method="POST">

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="name" name="name" class="form-control">
                            <label for="name" class="">Your name</label>
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="email" name="email" class="form-control">
                            <label for="email" class="">Your email</label>
                        </div>
                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form mb-0">
                            <input type="text" id="subject" name="subject" class="form-control">
                            <label for="subject" class="">Subject</label>
                        </div>
                    </div>
                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-12">

                        <div class="md-form">
                            <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                            <label for="message">Your message</label>
                        </div>

                    </div>
                </div>
                <!--Grid row-->

            </form>

            <div class="text-center text-md-left">
                <button class="btn btn-primary" ><!--onclick="document.getElementById('contact-form').submit();"-->Send</button>
            </div>
            <div class="status"></div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <!--Grid column-->

    </div>

</section>-->





/////







<style type="text/css">input.in-name {
        padding: 0;
        width: 25%;
        font-size: 12px;
    }

    button.btn.btn-primary.bew_pri {
        padding: 8px 18px 8px 18px;
        font-size: 12px;
        font-weight: bold;
        background-color: #003366;
    }

    li.selected {
        background: #ffc202!important;
        border: #ffc202!important;
    }
    ul.form .CapBody li input.MainBtn {
        background: #ffc202!important;
    }
    .CapBody {
        border: none;
    }
</style>
<div class="user" id="eMeeting">
    <div class="header account_tabs">
        <ul>
            <li class="selected mn-add" style="font-size:18px;"><a href="javascript:void(0)"><span>Contact us</span></a></li>
        </ul>

        <div class="ClearAll">&nbsp;</div>
    </div>
</div>

<div id="step_1" style="display:visible;">
    <div class="CapBody bd_padding_20">
        <form id="tell_friend">
            <ul>
                <li><label>Name:</label> <input class="input" id="C1" name="name" placeholder="Full Name" size="40" type="text" value="" /></li>
                <li><label>Email:</label> <input class="input" id="C2" name="email" placeholder=" Email" size="40" type="text" value="" /></li>
                <li><label>Subject:</label> <input class="input" id="C3" name="subject" placeholder=" Subject" size="40" type="text" value="" /></li>
                <li><label>Message:</label> <textarea class="input" id="C5" name="message" placeholder=" Message" size="40" type="text" value="" ></textarea></li>
                <li><input class="MainBtn" type="button" value="Submit" /></li>
            </ul>
        </form>
    </div>

    <ul>
    </ul>
</div>

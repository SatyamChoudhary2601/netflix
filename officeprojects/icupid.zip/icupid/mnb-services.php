
<div class="container">   
    
<h1 class="really-get text-center">REALLY GET TO KNOW ME</h1>
<p class="same-coler">Hobbies and interests </p> 
   <div class="row">
  

  <!-- <p>Hobbies and interests </p> -->
 <div class="col-3 same-color-width"> 
<p class="question">1.&nbsp;Do I enjoy gardening?</p>
<div class="really-hobbies-full"><input type="radio" value="yes" /><label>Yes</label></div> 
<div class="really-hobbies-full"><input type="radio" value="no" /> <label> NO</label></div> 
</div>

<div class="col-3 same-color-width">
<p class="question">2.&nbsp;Do I enjoy grocery shopping?</p>
<div class="really-hobbies-full"><input type="radio" value="yes" /><label>Yes</label> </div>
<div class="really-hobbies-full"><input type="radio" value="no" /> <label>NO</label></div>
</div>

<div class="col-3 same-color-width">
<p class="question">3.&nbsp;Do I enjoy cooking?</p>
<div class="really-hobbies-full"><input type="radio" value="yes" /><label>Yes</label></div> 
<div class="really-hobbies-full"><input type="radio" value="no" /> <label> NO</label></div>
</div>

<div class="col-3 same-color-width">
<p class="question">4.&nbsp;How often do I like to go out?</p>
<div class="really-hobbies-full"><input type="radio" value="Three or four times per week" /><label>Three or four times per week</label></div>
<div class="really-hobbies-full"><input type="radio" value="I’m a party animal!" /> <label> I&rsquo;m a party animal!</label></div> 
<div class="really-hobbies-full"><input type="radio" value="I’m homebody " /> <label>I&rsquo;m homebody </label></div>
</div>

<div class="col-3 same-color-width">
<p class="question">5.&nbsp;Do I enjoy dining out?</p>
<div class="really-hobbies-full"><input type="radio" value="Yes" /> <label>Yes</label></div> 
<div class="really-hobbies-full"><input type="radio" value="No" /> <label>No </label> </div>
<div class="really-hobbies-full"><input type="radio" value="Sometimes " /> <label>Sometimes </label> </div>
<div class="really-hobbies-full"><input type="radio" value="Sometimes " /> <label>I like home-cooked meals</label></div>
</div>

<div class="col-3 same-color-width"><p class="question">6.&nbsp;When it comes to TV:</p>
<div class="really-hobbies-full"><input type="radio" value="Love to watch" /> <label>Love to watch</label></div> 
<div class="really-hobbies-full"><input type="radio" value="Don’t watch at all" /> <label>Don&rsquo;t watch at all </label></div>
<div class="really-hobbies-full"><input type="radio" value="Occasionally " /> <label>Occasionally</label></div>
</div>

<div class="col-3 same-color-width">
<p class="question">7.&nbsp;When it comes to money:</p>
<div class="really-hobbies-full"><input type="radio" value="Love to spend" /> <label>Love to spend</label></div>
<div class="really-hobbies-full"><input type="radio" value="Love to save" /> <label>Love to save </label> </div>
<div class="really-hobbies-full"><input type="radio" value="It doesn’t make me happy  " /> <label>It doesn&rsquo;t make me happy </label></div> 
<div class="really-hobbies-full"><input type="radio" value="It give me choices " /> <label>It give me choices </label></div>
</div>

<div class="col-3 same-color-width">
<p class="question">8.&nbsp;Describe me at a party as a:</p>
<div class="really-hobbies-full"><input type="radio" value="Life of the party" /> <label>Life of the party</label></div>
<div class="really-hobbies-full"><input type="radio" value="Love to mingle" /><label>Love to mingle </label></div>
<div class="really-hobbies-full"><input type="radio" value="I’m  a wall lizard  " /><label> I&rsquo;m a wall lizard</label></div> 
<div class="really-hobbies-full"><input type="radio" value="A mellow or playful observer " /><label> A mellow or playful observer </label></div>
</div>

<div class="col-3 same-color-width">
<p class="question">9.&nbsp;I keep my space:</p>
<div class="really-hobbies-full"><input type="radio" value="Neat and tidy " /> <label>Neat and tidy</label> </div>
<div class="really-hobbies-full"><input type="radio" value="I’m a clean freak" /><label>I&rsquo;m a clean freak</label></div> 
<div class="really-hobbies-full"><input type="radio" value="I’m a little messy  " /> <label>I&rsquo;m a little messy </label></div>
<div class="really-hobbies-full"><input type="radio" value="I’m a little messy  " /> <label>I have to admit, I’m a slob</label></div>

</div>

</div><br>
<p class="same-coler">Preference for pets: </p> 
<div class="row">
<div class="col-3 same-color-width">  
<p class="question">1.&nbsp;Cats </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>I love cats</label> </div>
<div class="really-hobbies-full"><input type="radio"  /> <label>I’m not fond of cats at all</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label> I find them unpleasant </label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label>Too much fur</label></div>
</div>

<div class="col-3 same-color-width">  
<p class="question">2.&nbsp;Dogs </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>I love dogs</label></div> 
<div class="really-hobbies-full"><input type="radio"  /> <label>I’m not a dog fan</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label> My best friend </label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label>Great if they live outside</label></div>
</div>

<div class="col-3 same-color-width">  
<p class="question">3.&nbsp;Fish </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>I love fish</label> </div>
<div class="really-hobbies-full"><input type="radio"  /> <label>Too much work</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label> I don’t have the touch for fish</label></div>
</div>
<div class="col-3 same-color-width">  
<p class="question">4.&nbsp;Reptiles </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>A unique pet, not for me </label></div> 
<div class="really-hobbies-full"><input type="radio"  /> <label>I adore reptiles</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label> I’m scared of all snakes</label></div>
</div>
<div class="col-3 same-color-width"> 
<p class="question">4.&nbsp;Birds </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>I love my birds </label> </div>
<div class="really-hobbies-full"><input type="radio"  /> <label>I find them a little messy</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label>  I don’t have time for birds </label></div>
</div>
<div class="col-3 same-color-width"> 
<p class="question">5.&nbsp;Exotic pets </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>I do love exotic pets </label></div> 
<div class="really-hobbies-full"><input type="radio"  /> <label>Depends on your definition of exotic</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label>  I am not into exotic pets</label></div>
</div>
<div class="col-3 same-color-width">  
<p class="question">6.&nbsp;Rodents </p>
<div class="really-hobbies-full"><input type="radio"  /> <label>I love my rodents </label> </div>
<div class="really-hobbies-full"><input type="radio"  /> <label>I dislike all rodents</label></div>
<div class="really-hobbies-full"><input type="radio"  /> <label>  Any rodents except rats</label></div>
</div>
 
  </div><br>

<div class="row">
<div class="col-12 same-color-width auto-width-continue">
<p class="question">What type of Television programs do I enjoy watching most? </p>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Not Provided</label></div> 
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Sci-fi </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label> Sport </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Soaps </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>News  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Nature/wildlife </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Mystery/Thriller </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Horror  </label></div> <br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Game Shows </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Films  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Educational  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Drama  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Documentary   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Current Affairs/Debates  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Comedy   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Cartoons  </label></div>
</div>
    
<div class="col-12 same-color-width auto-width-continue">
<p class="question">I enjoy spending my free time </p>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Doing something athletic </label> </div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Curling up with a good book </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label> Having lunch with a friend  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>With family </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Doing absolutely nothing   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Playing with my pet  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Shopping </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Pottering in the garden   </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Visiting a museum or gallery  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Napping</label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Catching up on household chores   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Taking a class   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Pursuing a hobby    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Volunteering </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Watching TV or a movie    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Taking a walk   </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Among friends  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>In Nature </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Dancing in night clubs  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Playing on the computer  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Browsing the Internet  </label></div>
</div>


<div class="col-md-12 same-color-width auto-width-continue">
<p class="question">Activities that I enjoy   </p>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Aerobics </label> </div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Biking </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label> Boating/Sailing  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Camping </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Fishing   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Hiking  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Hunting </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Dancing  </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Playing Pool/Billiards   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Jogging/running  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Martial Arts   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Mountain climbing  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Skiing/Snowboarding     </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Snowmobiling </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Swimming   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Walking  </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Water skiing   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Weight lifting </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Playing ping pong   </label></div>
</div>

<div class="col-md-12 same-color-width auto-width-continue">
<p class="question">Sports that I enjoy watching and playing  </p>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Auto racing  </label> </div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Baseball </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label> Basketball </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Bowling </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Cricket   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Diving  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Extreme sports  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Figure skating   </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Football   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Golf </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Hockey   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Olympic sports   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Soccer     </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Squash/racquetball  </label></div>
</div>
    
<div class="col-md-12 same-color-width auto-width-continue">
<p class="question">Forms of entertainment that I enjoy  </p>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Bars/pubs </label> </div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Board Games  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label> Casino/gambling </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Concerts </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Dance clubs    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Darts  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Dinner parties  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Fashion events  </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Fine dining </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Movies </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Museum/arts    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Bird watching  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Mountain Climbing      </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Parachuting </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Cave exploration   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Canoeing  </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Going to the Circus  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Poetry</label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Reading  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Surfing the web  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>TV Educational/news   </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Bungie jumping  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>Video games  </label></div>
</div>
    
<div class="col-md-12 same-color-width auto-width-continue"><p class="question">Other hobbies or interests  </p>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>antiques </label> </div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>astrology </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label> cars collection </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>making websites </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>stamp collecting    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>building computers  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>crafts  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>creative writing  </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>dogs</label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>family/kid </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>gardening    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>gourmet cooking  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>home improvement      </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>investing </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>motorcycles  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>news/politics/events   </label></div><br>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>painting </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>philosophy/spiritual </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>photography  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>coaching children sports  </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>social cause/activism    </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>travelling </label></div>
<div class="really-hobbies-full"><input type="checkbox"  /> <label>volunteer  </label></div>
</div>
</div>
</div>  
  <div class="text-center gi-omakig-inner">        
    <a href="https://dev.mynewbride.com/page/Match-Making" style="text-decoration: none;">
      <input type="submit" name="submit" value="&nbsp;&nbsp;Update&nbsp;&nbsp;" class="NormBtn green-btn1">
    </a>
  </div>
  </form>
</div>
</div>
</div>
   <div id="search_modal1" class="modal " style="padding-top: 70px;margin-left: 150px;width: 35%;height: 439px;">


      <!-- Modal content -->
      <div class="modal-content">
      <span class="search_modal_close" style="text-align: right;
    font-size: 30px;">&times;</span>

    </div>
    </div> 
<script>  
  // for search modal
  $('#search_modal_myBtn').on('click', function(){
    

    $('#search_modal').show();
  });
  
  $('.search_modal_close').on('click', function(){
    $('#search_modal').hide();
  });
  
  $('.open_page').click(function(){
	 window.location.href= $(this).attr('href'); 
	  
  });	  
  
</script> 
<style>
    
.content {
    margin-top: 0px;
}
.CapBody
{
    display: none;
}
.edit-form-heading
{
      font-weight: bold;
    font-size: 35px;
}
</style>

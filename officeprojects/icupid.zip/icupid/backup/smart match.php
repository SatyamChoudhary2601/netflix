
/* margin-bottom: 12px;*/

<style type="text/css">
    .matcmaking-qustion h1 {
        text-align: center;
        font-size: 56px;
        float: left;
        line-height: 92px;
        width: 100%;
    }
    .matcmaking-qustion p {
        text-align: center;
        font-size: 16px;
    }
    .qution-makig-inner {
        margin-top: 20px;
        width: 100%;
        float: left;
    }
    .qution-makig-inner ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    .qution-makig-inner ul li {
        width: 100%;
        float: left;
        margin-bottom: 15px;
        font-size: 16px;
        font-weight: 600;
        border-bottom: 1px #ccc solid;
        padding-bottom: 15px;
    }
    .qution-makig-inner ul li span {
        width: 100%;
        float: left;
        font-size: 15px;
        font-weight: 400;
        margin-top: 6px;
    }
    .qution-makig-inner ul li span input[type="radio"] {
        display: inline-block;
        width: auto;
        margin: 0 7px;
    }
</style>
<div class="matcmaking-qustion">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Compatibility Quiz</h1>

                <p><span style="color:#f94340;float: left;width: 100%;text-align: left;margin-top: 20px;"><span style="font-size:18px;"><b>Communication Style</b></span></span></p>

                <div class="qution-makig-inner">
                    <ul>
                        <li>1. When my partner and I are having an issue, I like to talk it through until it is resolved. <span><input type="radio" /> Yes <input type="radio" /> No</span></li>
                        <li>2. When I disagree with someone, I will usually tell them. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>3. Do you agree with the statement: &quot;If you don&#39;t have anything nice to say, don&#39;t say anything at all&quot;? <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>4.&nbsp;You are having an argument and you realise you are wrong. What do you do? <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>5. I try to avoid confrontation. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>6. I stand up for my beliefs no matter what. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>7. Have you ever ghosted someone before? (stopped communicating with a potential partner without explanation). <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                    </ul>
                </div>
                <span style="color:#f94340;float: left;width: 100%;margin-top: 20px;"><b><span style="font-size:18px;">Romance / Intimacy</span></b></span>

                <div class="qution-makig-inner">
                    <ul>
                        <li>1. Do you like it when your partner is romantic? <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>2. Do you consider yourself a romantic person? <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>3. I believe monogamy is essential in a relationship. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>4. I am a very affectionate person. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>5. I like to bring romance into my relationship. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>6. I&#39;m not a very touchy-feely person. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>7. Have you ever ghosted someone before? (stopped communicating with a potential partner without explanation). <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                    </ul>
                </div>
                <span style="color:#f94340;float: left;width: 100%;margin-top: 20px;"><span style="font-size:18px;"><b>Emotional Stability</b></span></span>

                <div class="qution-makig-inner">
                    <ul>
                        <li>1. I have little patience. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>2. I get angry pretty easily. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>3. I get stressed easily. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>4. My emotions tend to get out of control. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        <li>5. Someone cuts you off in traffic, what do you do?</li>
                        <li><span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                    </ul>
                    <span style="color:#f94340;float: left;width: 100%;margin-top: 20px;"><span style="font-size:18px;"><b>Sense of Humour</b></span></span>

                    <div class="qution-makig-inner">
                        <ul>
                            <li>1. Are you more serious or humorous when talking to others? <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                            <li>2. I was a bit of a class clown in school. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                            <li>3. I love making other people laugh. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                            <li>4. I enjoy watching stand-up comedy. <span><input type="radio" /> Yes <input type="radio" /> No </span></li>
                        </ul>

                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

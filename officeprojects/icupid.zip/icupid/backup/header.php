<?php
if($_SESSION['username']!='Guest'){ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?=$HEADER_META_TITLE ?></title>
  <meta name="keywords" content="<?=$HEADER_META_KEYWORDS ?>" />
  <meta name="description" content="<?=$HEADER_META_DESCRIPTION ?>" />
  <meta http-equiv="Content-Type" content="text/html; charset=<?=$HEADER_META_CHARSET ?>">
  <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <?=$HEADER_META_BASE ?>
  <?php e_meta(); ?>
  <?=(isset($HEADER_ANALYTICS)) ? $HEADER_ANALYTICS : "";?>

  <?php require_once __DIR__ .'/../layout/header_scripts.php' ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/inc/templates/<?=D_TEMP ?>/css/bootstrap.min.css">
  <link rel="stylesheet" href="/inc/templates/<?=D_TEMP ?>/css/custom.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">       
    
  <script src="/inc/templates/<?=D_TEMP ?>/js/bootstrap.min.js"></script>
  <script src="/inc/templates/<?=D_TEMP ?>/js/jquery.min.js"></script>
  <script src="/inc/templates/<?=D_TEMP ?>/js/popper.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker_3" ).datepicker();
  } );
  </script>
    <style>
        a{
            text-decoration: none !important;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="header">
         
  <section class="service ">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ul>
                
        <li class="onthis">
          <a href="https://dev.mynewbride.com/page/mnb-services" class="slect-service">
                <span>MNB Concierge Services</span>
          </a>
        </li>
        <li>
          <button onclick="location.href='https://dev.mynewbride.com/page/FIRST-MEETING';" class="slect-service">Arrange for First Meeting</button>
        </li>
        <li>
            <button onclick="location.href='https://dev.mynewbride.com/page/BOOK-A-FLIGHT';"  class="slect-service">
           Book a Flight</button>
        </li>
        <li>
          <button onclick="location.href='https://dev.mynewbride.com/page/BOOK-HOTEL';"  class="slect-service">Book Hotel</button>
        </li>
        <li><button onclick="location.href='https://dev.mynewbride.com/page/PRE-TRIP-INFO';"  class="slect-service">
                PRE-TRIP INFORMATION & SUGGESTION</button></li>
        <li><button onclick="location.href='https://dev.mynewbride.com/page/LANGUAGE-SCHOOL';"  class="slect-service">
                ARRANGE FOR LANGUAGE SCHOOL OR COURSES</button></li>
        <li><button onclick="location.href='https://dev.mynewbride.com/page/DOC-IMMIGR';"  class="slect-service">
                Document Preparation & Immigration Services</button></li>
        <!-- <li><button class="slect-service">IMMIGRATION SERVICES</button></li> -->
        <li><button onclick="location.href='https://dev.mynewbride.com/page/WEDDING-PLANNER';"  class="slect-service">
                Wedding Planner Choices</button></li>
        <li><button onclick="location.href='https://dev.mynewbride.com/page/ORDER-CAKE';"  class="slect-service">
                Order your Cake</button></li>
        <li><button onclick="location.href='https://dev.mynewbride.com/page/BOOK-PHOTO';"  class="slect-service">
                Book a Photographer</button></li>
        <li><button onclick="location.href='https://dev.mynewbride.com/page/LIMO-SERVICES';"  class="slect-service">
                Limousines Services</button></li>
        <!--<li><button onclick="location.href='https://dev.mynewbride.com/page/HONEYMOON-PKG';"  class="slect-service">
                Honeymoon Package</button></li>-->
        <li><button onclick="location.href='https://dev.mynewbride.com/page/BIG-WEDDING-DAY';"  class="slect-service">The Big Wedding Day</button></li>
                
        
                </ul>    
                
               
            </div>
                  
      
      
      
        </div>
    
    
      
    
    
    </div>    
</section> 
        <div id="myModal" class="modal" style="padding-top: 70px;
    margin-left: 540px;width: 35%;">


      <!-- Modal content -->
      <div class="modal-content">
      <span class="close" style="text-align: right;
    font-size: 30px;">×</span>
      <div class="row" style="padding-left: 60px;">
        <div class="column">
        <h2>Click to Download</h2>
      <img style="text-align: center;width: 176px;" src="https://thumbs.dreamstime.com/t/app-store-google-play-icons-color-icons-app-store-google-play-colors-vector-illustration-145688828.jpg" >
        </div>
        <div class="column">
        <h2>Scan QR Code to download</h2>
        <img style="margin-left: 100px;
    margin-top: 20px;" id='barcode' 
            src="https://api.qrserver.com/v1/create-qr-code/?data=HelloWorld&size=100x100" 
            alt="" 
            title="HELLO" 
            width="50" 
            height="50" />
        </div>
      </div>
      </div>

    </div>
    </div>
    
    

    
<script>
  // Get the modal for APP
  $( document ).ready(function() {
    
});
    
  var modal = document.getElementById("myModal");

  // Get the button that opens the modal
  var btn = document.getElementById("myBtn");

  // Get the <span> element that closes the modal
  var span = document.getElementsByClassName("close")[0];
   /* $( "#myBtn" ).mouseover(function() {
    event.preventDefault(); 
      modal.style.display = "block";
});*/
    /*$( "#myBtn" ).mouseout(function() {
    event.preventDefault(); 
      modal.style.display = "none";
});*/


  // When the user clicks the button, open the modal 
  /*btn.onclick = function(event) {
    event.preventDefault(); 
    modal.style.display = "block";
  }
*/
  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    event.preventDefault(); 
    if (event.target == modal) {
    modal.style.display = "none";
    }
  }
   $( document ).ready(function() {
    
   /*setInterval(function () {
       var last = $('.logo').last().css({opacity: '0', width: '20px'});
    last.prependTo('.showrooms');
    last.animate({opacity: '1', width: '152px'});
    },3000);*/
    
});
</script>


    
        <div class="container ">
            <div class="row">
                <div class="col-md-12">
                    <div class="logo-images-nav">
                    <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/logo-inner.jpg" class="logo-width">
                    
                    <div class="right-nav-images thumbnailgallery">
                      <div class="showrooms clearfix"> 
                   
                    <div class='photo-slider logo'>
                    <img class="imagesrandom"  src="/inc/templates/<?=D_TEMP ?>/images/new_images/header-img-2.jpg" alt="">
                    <div class='photo-status'>Julit,&nbsp;<span class="my_age">24</span><span class="online">online</span></div>
                </div>
                <div class='photo-slider logo'>
                    <img class="imagesrandom "  src="/inc/templates/<?=D_TEMP ?>/images/new_images/header-img-3.jpg" alt="">
                   <div class='photo-status'>Antesia,&nbsp;<span class="my_age">24</span><span class="online">online</span></div>
                </div>
                     <div class='photo-slider logo'>
                    <img class="imagesrandom"  src="/inc/templates/<?=D_TEMP ?>/images/new_images/header-img-4.jpg" alt=""> 
                    <div class='photo-status'>Julia,&nbsp;<span class="my_age">26</span><span class="online">online</span></div>
                </div>   
                <div class='photo-slider logo'>
          <img class="imagesrandom"  src="/inc/templates/<?=D_TEMP ?>/images/new_images/header-img-1.jpg" alt="">  
          <div class='photo-status'>Zeta,&nbsp;<span class="my_age">30</span><span class="online">online</span></div>
                </div>    
           <div class='photo-slider logo'>
                    <img class="imagesrandom"  src="/inc/templates/<?=D_TEMP ?>/images/new_images/header-img-4.jpg" alt=""> 
                   <div class='photo-status'>July,&nbsp;<span class="my_age">29</span><span class="online">online</span></div>
                </div>  
                    </div>    
                    </div>
                </div>
            </div>
             </div>
             </div>
      
  
      
        </div>
    </div>
  
 
 <div class="background-color-top">
             <?php
                if(isset($_SESSION['lang'])){
                    $lang = $_SESSION['lang'];
                    $$lang = "selected = 'selected'";
                }
                else{
                    $english = "selected = 'selected'";
                }
                ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="margin-top;margin-left: -66px;">
                    <nav class="navbar navbar-expand-sm">
                      <ul class="navbar-nav">                                                                         
                        <li><a href="https://dev.mynewbride.com" onclick="window.open('https://dev.mynewbride.com','_self')">Home</a></li>
                        <li><a href="https://dev.mynewbride.com/page/AboutUs" onclick="window.open('https://dev.mynewbride.com/page/AboutUs','_self')">About Us</a></li>
                        <li><a href="https://dev.mynewbride.com/search/advanced" onclick="window.open('https://dev.mynewbride.com/search/advanced','_self')">Search</a></li>
                          <!--https://dev.mynewbride.com/search  -->
                        <li><a href="https://dev.mynewbride.com/page/prifile-section" onclick="window.open('https://dev.mynewbride.com/page/prifile-section','_self')">My Profile</a></li>
                        <li class="hd-link"><a href="https://dev.mynewbride.com/page/my-account" onclick="window.open('https://dev.mynewbride.com/page/my-account,'_self')">My Account</a></li>
                        <li><a href="https://dev.mynewbride.com/page/support" onclick="window.open('https://dev.mynewbride.com/page/support','_self')">Support</a></li>
                         <li><a href="https://dev.mynewbride.com/page/contact-us" onclick="window.open('https://dev.mynewbride.com/page/contact-us','_self')">Contact Us</a></li>

                        <li><a href="http://onelink.to/hjwtp6" onclick="window.open('http://onelink.to/hjwtp6','_self')" id="myBtn"><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/mobile-icon.png" alt="" height="25px" width="23px">&nbsp;App </a></li>
                        <!-- <li><a href="#">QR</a></li>  -->
                         
                         <?php if(isset($_SESSION["uid"])):?>
                          <li><a href="/inc/logout.php" onclick="location.href='/inc/logout.php';">Logout</a></li>
                        <?php endif;
                        ?>

                                       
                <form class="f_left">
                    <select class="language f_left padding_5" name="lang" id="lang" onchange="location = this.options[this.selectedIndex].value;"> 
                        <option value="/index.php?l=english" <?php if(isset($english)){ echo $english;}?>>English</option>
                        <option value="/index.php?l=bosnian" <?php if(isset($bosnian)){ echo $bosnian;}?>>Bosnian</option>
                        <option value="/index.php?l=turkey" <?php if(isset($turkey)){ echo $turkey;}?>>Turkey</option>
                        <option value="/index.php?l=spanish" <?php if(isset($spanish)){ echo $spanish;}?>>Spanish</option>
                        <option value="/index.php?l=russian" <?php if(isset($russian)){ echo $russian;}?>>Russian</option>
                        <option value="/index.php?l=czech" <?php if(isset($czech)){ echo $czech;}?>>Czech</option>
                        <option value="/index.php?l=japanese" <?php if(isset($japanese)){ echo $japanese;}?>>Japanese</option>
                        <option value="/index.php?l=slovenian" <?php if(isset($slovenian)){ echo $slovenian;}?>>Slovenian</option>
                        <option value="/index.php?l=swedish" <?php if(isset($swedish)){ echo $swedish;}?>>Swedish</option>
                        <option value="/index.php?l=slovak" <?php if(isset($slovak)){ echo $slovak;}?>>Slovak</option>
                        <option value="/index.php?l=thai" <?php if(isset($thai)){ echo $thai;}?>>Thai</option>
                        <option value="/index.php?l=danish" <?php if(isset($danish)){ echo $danish;}?>>Danish</option>
                        <option value="/index.php?l=chinese" <?php if(isset($chinese)){ echo $chinese;}?>>Chinese</option>
                        <option value="/index.php?l=romanian" <?php if(isset($romanian)){ echo $romanian;}?>>Romanian</option>
                        <option value="/index.php?l=german" <?php if(isset($german)){ echo $german;}?>>German</option>
                        <option value="/index.php?l=italian" <?php if(isset($italian)){ echo $italian;}?>>Italian</option>
                        <option value="/index.php?l=vietnamese" <?php if(isset($vietnamese)){ echo $vietnamese;}?>>Vietnamese</option>
                        <option value="/index.php?l=arabic" <?php if(isset($arabic)){ echo $arabic;}?>>Arabic</option>
                        <option value="/index.php?l=portugues" <?php if(isset($portugues)){ echo $portugues;}?>>Portugues</option>
                        <option value="/index.php?l=norwegian" <?php if(isset($norwegian)){ echo $norwegian;}?>>Norwegian</option>
                        <option value="/index.php?l=dutch" <?php if(isset($dutch)){ echo $dutch;}?>>Dutch</option>
                        <option value="/index.php?l=korean" <?php if(isset($korean)){ echo $korean;}?>>Korean</option>
                        <option value="/index.php?l=croatian" <?php if(isset($croatian)){ echo $croatian;}?>>Croatian</option>
                        <option value="/index.php?l=taiwanese" <?php if(isset($taiwanese)){ echo $taiwanese;}?>>Taiwanese</option>
                        <option value="/index.php?l=polish" <?php if(isset($polish)){ echo $polish;}?>>Polish</option>
                        <option value="/index.php?l=french" <?php if(isset($french)){ echo $french;}?>>French</option>
                        <option value="/index.php?l=greek" <?php if(isset($greek)){ echo $greek;}?>>Greek</option>
                    </select>
                    <? if($page == "index"){ ?>
                        <a class="login login-btn" href="">Login Here</a>
                    <? } ?>
                </form>
                
                      </ul>  
                    </nav>
                </div>
            </div>
        </div>
        </div> 
    <?php 

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];


    if (strpos($url , 'https://dev.mynewbride.com/page/prifile-section') !== FALSE)
:
include_once('profile.php');
?>

<?php endif;?>
<?php if (strpos($url , 'https://dev.mynewbride.com/page/new-email') !== FALSE):
include_once('new-email.php');
 

     endif;
if (strpos($url , 'https://dev.mynewbride.com/page/logout-frontend') !== FALSE):

include_once('logout.php');
    endif;
if (strpos($url , 'https://dev.mynewbride.com/page/SEND-FLOWERS') !== FALSE):

include_once('send-flower.php');
    endif;
    if (strpos($url , 'https://dev.mynewbride.com/page/VIRTUAL-GIFTSS') !== FALSE):

include_once('virtual-gift.php');
    endif;

    if (strpos($url , 'https://dev.mynewbride.com/page/gift') !== FALSE):

include_once('send-gift.php');
    endif;
    if (strpos($url , 'https://dev.mynewbride.com/page/MEMBERS-ONLY') !== FALSE):

include_once('member-online.php');
    endif;
    if (strpos($url , 'https://dev.mynewbride.com/page/girl-profile') !== FALSE):

include_once('girl-profile.php');
    endif;

    if (strpos($url , 'https://dev.mynewbride.com/page/edit-profile') !== FALSE):

include_once('edit-profile.php');
    endif;

    
    if (strpos($url , 'https://dev.mynewbride.com/page/inroduce') !== FALSE):

include_once('inroduce.php');
    endif;


    if (strpos($url , 'https://dev.mynewbride.com/page/mnb-services.php') !== FALSE):

include_once('mnb-services.php');
    endif;


// if (strpos($url , 'https://dev.mynewbride.com/page/my-account') !== FALSE):

// include_once('my-account.php');
//     endif;
 /*if (strpos($url , 'https://dev.mynewbride.com/page/hobbies') !== FALSE):

include_once('hobbies.php');
    endif;*/



     ?>
      
<script>
 //$('.slect-service').on('click',function(){
 // $('.search_bar').toggle(1000);
 //});
 //$('.imagesrandom').each(function() {
    
    //randomElm = $('.imagesrandom').get(Math.floor(Math.random()*10));
   // randomElm.parentNode.insertBefore(this, randomElm);
//});
</script>



    
<section class="slider-form">
    <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/home_image.jfif" alt=""> 
</section> 
    
  <section class="service search_bar">
    <div class="container">
        <div class="row">
                <div class="col-md-12" style="text-align: center;font-weight: 800;">
          <button style="font-size:27px" id="search_modal_myBtn" type="button" class="btn btn-primary blue-bc">Find Your Matches</button>

          
          
          <form class="form-inline" style="    text-align: center;
    padding-left: 314px;display:none;">
            <div class="form-group">
            MAN | WOMAN
            </div>
            &nbsp;&nbsp;
            <div class="form-group">
            <select class="form-control" id="sel1">
              <option>Age</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
             </select>
            </div>
            &nbsp;&nbsp;
            <div class="form-group">
            <select class="form-control" id="sel1">
              <option>Country</option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
             </select>
            </div>
            &nbsp;&nbsp;
            <div class="form-group">
            <select class="form-control" id="sel1">
              <option>State/Province</option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              </select>           </div>
            &nbsp;&nbsp;            
          </form>
          
          
        </div>
       </div>
    </div>    
</section> 

<div id="search_modal" class="modal " style="padding-top: 70px;margin-left: 150px;width: 35%;height: 439px;">


      <!-- Modal content -->
      <div class="modal-content">
      <span class="search_modal_close" style="text-align: right;
    font-size: 30px;">×</span>
      <div class="row" style="padding-left: 35px;">
                
        <form action="/action_page.php">
              <div class="row">
    <div class="col-4">
 
          <div class="form-group col-12" style="margin-bottom: 3rem;">
         
           <div  class="row">
             <label for="email">Age</label>
          <div class="col-3">
            <select>
            <?php for($i=18;$i<79;$i++):?>

           <option value="<?php echo $i;?>"><?php echo $i;?></option>
          <?php endfor;?>
        </select>
      </div>
      
          <div class="col-3">
          <select>
            <?php for($i=18;$i<79;$i++):?>

           <option value="<?php echo $i;?>"><?php echo $i;?></option>
          <?php endfor;?>
        </select>
        </div>
          </div>
        </div>
      </div>

       <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Country</label>
          
<select>
<option Value="" Selected="True">Select Country</option>
<option Value="AF">Afghanistan</option>
<option Value="AL">Albania</option>
<option Value="DZ">Algeria</option>
<option Value="AS">American Samoa</option>
<option Value="AD">Andorra</option>
<option Value="AO">Angola</option>
<option Value="AI">Anguilla</option>
<option Value="AQ">Antarctica</option>
<option Value="AG">Antigua And Barbuda</option>
<option Value="AR">Argentina</option>
<option Value="AM">Armenia</option>
<option Value="AW">Aruba</option>
<option Value="AU">Australia</option>
<option Value="AT">Austria</option>
<option Value="AZ">Azerbaijan</option>
<option Value="BS">Bahamas</option>
<option Value="BH">Bahrain</option>
<option Value="BD">Bangladesh</option>
<option Value="BB">Barbados</option>
<option Value="BY">Belarus</option>
<option Value="BE">Belgium</option>
<option Value="BZ">Belize</option>
<option Value="BJ">Benin</option>
<option Value="BM">Bermuda</option>
<option Value="BT">Bhutan</option>
<option Value="BO">Bolivia</option>
<option Value="BA">Bosnia And Herzegowina</option>
<option Value="BW">Botswana</option>
<option Value="BV">Bouvet Island</option>
<option Value="BR">Brazil</option>
<option Value="IO">British Indian Ocean Territory</option>
<option Value="BN">Brunei Darussalam</option>
<option Value="BG">Bulgaria</option>
<option Value="BF">Burkina Faso</option>
<option Value="BI">Burundi</option>
<option Value="KH">Cambodia</option>
<option Value="CM">Cameroon</option>
<option Value="CA">Canada</option>
<option Value="CV">Cape Verde</option>
<option Value="KY">Cayman Islands</option>
<option Value="CF">Central African Republic</option>
<option Value="TD">Chad</option>
<option Value="CL">Chile</option>
<option Value="CN">China</option>
<option Value="CX">Christmas Island</option>
<option Value="CC">Cocos (Keeling) Islands</option>
<option Value="CO">Colombia</option>
<option Value="KM">Comoros</option>
<option Value="CG">Congo</option>
<option Value="CK">Cook Islands</option>
<option Value="CR">Costa Rica</option>
<option Value="CI">Cote D'Ivoire</option>
<option Value="HR">Croatia (Local Name: Hrvatska)</option>
<option Value="CU">Cuba</option>
<option Value="CY">Cyprus</option>
<option Value="CZ">Czech Republic</option>
<option Value="DK">Denmark</option>
<option Value="DJ">Djibouti</option>
<option Value="DM">Dominica</option>
<option Value="DO">Dominican Republic</option>
<option Value="TP">East Timor</option>
<option Value="EC">Ecuador</option>
<option Value="EG">Egypt</option>
<option Value="SV">El Salvador</option>
<option Value="GQ">Equatorial Guinea</option>
<option Value="ER">Eritrea</option>
<option Value="EE">Estonia</option>
<option Value="ET">Ethiopia</option>
<option Value="FK">Falkland Islands (Malvinas)</option>
<option Value="FO">Faroe Islands</option>
<option Value="FJ">Fiji</option>
<option Value="FI">Finland</option>
<option Value="FR">France</option>
<option Value="GF">French Guiana</option>
<option Value="PF">French Polynesia</option>
<option Value="TF">French Southern Territories</option>
<option Value="GA">Gabon</option>
<option Value="GM">Gambia</option>
<option Value="GE">Georgia</option>
<option Value="DE">Germany</option>
<option Value="GH">Ghana</option>
<option Value="GI">Gibraltar</option>
<option Value="GR">Greece</option>
<option Value="GL">Greenland</option>
<option Value="GD">Grenada</option>
<option Value="GP">Guadeloupe</option>
<option Value="GU">Guam</option>
<option Value="GT">Guatemala</option>
<option Value="GN">Guinea</option>
<option Value="GW">Guinea-Bissau</option>
<option Value="GY">Guyana</option>
<option Value="HT">Haiti</option>
<option Value="HM">Heard And Mc Donald Islands</option>
<option Value="VA">Holy See (Vatican City State)</option>
<option Value="HN">Honduras</option>
<option Value="HK">Hong Kong</option>
<option Value="HU">Hungary</option>
<option Value="IS">Icel And</option>
<option Value="IN">India</option>
<option Value="ID">Indonesia</option>
<option Value="IR">Iran (Islamic Republic Of)</option>
<option Value="IQ">Iraq</option>
<option Value="IE">Ireland</option>
<option Value="IL">Israel</option>
<option Value="IT">Italy</option>
<option Value="JM">Jamaica</option>
<option Value="JP">Japan</option>
<option Value="JO">Jordan</option>
<option Value="KZ">Kazakhstan</option>
<option Value="KE">Kenya</option>
<option Value="KI">Kiribati</option>
<option Value="KP">Korea, Dem People'S Republic</option>
<option Value="KR">Korea, Republic Of</option>
<option Value="KW">Kuwait</option>
<option Value="KG">Kyrgyzstan</option>
<option Value="LA">Lao People'S Dem Republic</option>
<option Value="LV">Latvia</option>
<option Value="LB">Lebanon</option>
<option Value="LS">Lesotho</option>
<option Value="LR">Liberia</option>
<option Value="LY">Libyan Arab Jamahiriya</option>
<option Value="LI">Liechtenstein</option>
<option Value="LT">Lithuania</option>
<option Value="LU">Luxembourg</option>
<option Value="MO">Macau</option>
<option Value="MK">Macedonia</option>
<option Value="MG">Madagascar</option>
<option Value="MW">Malawi</option>
<option Value="MY">Malaysia</option>
<option Value="MV">Maldives</option>
<option Value="ML">Mali</option>
<option Value="MT">Malta</option>
<option Value="MH">Marshall Islands</option>
<option Value="MQ">Martinique</option>
<option Value="MR">Mauritania</option>
<option Value="MU">Mauritius</option>
<option Value="YT">Mayotte</option>
<option Value="MX">Mexico</option>
<option Value="FM">Micronesia, Federated States</option>
<option Value="MD">Moldova, Republic Of</option>
<option Value="MC">Monaco</option>
<option Value="MN">Mongolia</option>
<option Value="MS">Montserrat</option>
<option Value="MA">Morocco</option>
<option Value="MZ">Mozambique</option>
<option Value="MM">Myanmar</option>
<option Value="NA">Namibia</option>
<option Value="NR">Nauru</option>
<option Value="NP">Nepal</option>
<option Value="NL">Netherlands</option>
<option Value="AN">Netherlands Ant Illes</option>
<option Value="NC">New Caledonia</option>
<option Value="NZ">New Zealand</option>
<option Value="NI">Nicaragua</option>
<option Value="NE">Niger</option>
<option Value="NG">Nigeria</option>
<option Value="NU">Niue</option>
<option Value="NF">Norfolk Island</option>
<option Value="MP">Northern Mariana Islands</option>
<option Value="NO">Norway</option>
<option Value="OM">Oman</option>
<option Value="PK">Pakistan</option>
<option Value="PW">Palau</option>
<option Value="PA">Panama</option>
<option Value="PG">Papua New Guinea</option>
<option Value="PY">Paraguay</option>
<option Value="PE">Peru</option>
<option Value="PH">Philippines</option>
<option Value="PN">Pitcairn</option>
<option Value="PL">Poland</option>
<option Value="PT">Portugal</option>
<option Value="PR">Puerto Rico</option>
<option Value="QA">Qatar</option>
<option Value="RE">Reunion</option>
<option Value="RO">Romania</option>
<option Value="RU">Russian Federation</option>
<option Value="RW">Rwanda</option>
<option Value="KN">Saint K Itts And Nevis</option>
<option Value="LC">Saint Lucia</option>
<option Value="VC">Saint Vincent, The Grenadines</option>
<option Value="WS">Samoa</option>
<option Value="SM">San Marino</option>
<option Value="ST">Sao Tome And Principe</option>
<option Value="SA">Saudi Arabia</option>
<option Value="SN">Senegal</option>
<option Value="SC">Seychelles</option>
<option Value="SL">Sierra Leone</option>
<option Value="SG">Singapore</option>
<option Value="SK">Slovakia (Slovak Republic)</option>
<option Value="SI">Slovenia</option>
<option Value="SB">Solomon Islands</option>
<option Value="SO">Somalia</option>
<option Value="ZA">South Africa</option>
<option Value="GS">South Georgia , S Sandwich Is.</option>
<option Value="ES">Spain</option>
<option Value="LK">Sri Lanka</option>
<option Value="SH">St. Helena</option>
<option Value="PM">St. Pierre And Miquelon</option>
<option Value="SD">Sudan</option>
<option Value="SR">Suriname</option>
<option Value="SJ">Svalbard, Jan Mayen Islands</option>
<option Value="SZ">Sw Aziland</option>
<option Value="SE">Sweden</option>
<option Value="CH">Switzerland</option>
<option Value="SY">Syrian Arab Republic</option>
<option Value="TW">Taiwan</option>
<option Value="TJ">Tajikistan</option>
<option Value="TZ">Tanzania, United Republic Of</option>
<option Value="TH">Thailand</option>
<option Value="TG">Togo</option>
<option Value="TK">Tokelau</option>
<option Value="TO">Tonga</option>
<option Value="TT">Trinidad And Tobago</option>
<option Value="TN">Tunisia</option>
<option Value="TR">Turkey</option>
<option Value="TM">Turkmenistan</option>
<option Value="TC">Turks And Caicos Islands</option>
<option Value="TV">Tuvalu</option>
<option Value="UG">Uganda</option>
<option Value="UA">Ukraine</option>
<option Value="AE">United Arab Emirates</option>
<option Value="GB">United Kingdom</option>
<option Value="US">United States</option>
<option Value="UM">United States Minor Is.</option>
<option Value="UY">Uruguay</option>
<option Value="UZ">Uzbekistan</option>
<option Value="VU">Vanuatu</option>
<option Value="VE">Venezuela</option>
<option Value="VN">Viet Nam</option>
<option Value="VG">Virgin Islands (British)</option>
<option Value="VI">Virgin Islands (U.S.)</option>
<option Value="WF">Wallis And Futuna Islands</option>
<option Value="EH">Western Sahara</option>
<option Value="YE">Yemen</option>
<option Value="ZR">Zaire</option>
<option Value="ZM">Zambia</option>
<option Value="ZW">Zimbabwe</option>
</select>
    </div>
    </div>
    <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Level  Of English</label>
        <select>
         <option value="Does Not Matter">Does Not Matter</option>
         <option  value="NONE">NONE</option>
         <option  value="INTERMEDIATE">INTERMEDIATE</option>
         <option  value="GOOD">GOOD</option>
        <option  value="ALMOST FLUENT">ALMOST FLUENT </option>
         <option  value="FLUENT">FLUENT</option>
      
      </select>
          </div>
    </div>
    </div>
    <div class="row">
       <div class="col-4">
          <div class="form-group col-12" style="margin-bottom: 3rem;">
         
           <div  class="row">
             <label for="email">Height</label>
          <div class="col-3">
           <select>
         <option value="5’0” 152.40cm">5’0” 152.40cm</option>
         <option  value="5’1” 154.94cm">5’1” 154.94cm</option>
         <option  value="5’2” 157.48cm">5’2” 157.48cm</option>
         <option  value="D5’3” 160.02cm">5’3” 160.02cm</option>
        <option  value="5’4” 162.56cm">5’4” 162.56cm </option>
         <option  value="5’5” 165.10cm">5’5” 165.10cm</option>
         <option  value="5’6” 167.74cm">5’6” 167.74cm</option>
          <option  value="5’7” 170.18cm">5’7” 170.18cm</option>
          <option  value="5’8” 172.72cm">5’8” 172.72cm</option>
          <option  value="5’9” 175.26cm">5’9” 175.26cm</option>
          <option  value="5’11” 180.34cm">5’11” 180.34cm</option>
          <option  value="6’0” 182.88cm">6’0” 182.88cm</option>
          <option  value="6’1” 185.45cm">6’1” 185.45cm</option>
          <option  value="6’2” 187.96cm">6’2” 187.96cm</option>
          <option  value="6’3” 190.50cm">6’3” 190.50cm</option>
          <option  value="6’4” 193.04cm">6’4” 193.04cm</option>
          <option  value="6’5” 195.58cm">6’5” 195.58cm</option>
           <option  value="6’6” 198.12cm">6’6” 198.12cm</option>
            <option  value="6’7” 200.66cm">6’7” 200.66cm</option>
             <option  value="6’8” 203.20cm">6’8” 203.20cm</option>
              <option  value="6’9” 205.74cm">6’9” 205.74cm</option>
               <option  value="6’10” 208.28cm">6’10” 208.28cm</option>
                <option  value="6’11” 210.82cm">6’11” 210.82cm</option>
                 <option  value="7’0” 213.36cm">7’0” 213.36cm</option>
                 <option  value="7’1” 215.90cm">7’1” 215.90cm</option>
                 <option  value="7’2” 218.44cm">7’2” 218.44cm</option>
      </select>
      </div>
      
          <div class="col-3">
         <select>
         <option value="5’0” 152.40cm">5’0” 152.40cm</option>
         <option  value="5’1” 154.94cm">5’1” 154.94cm</option>
         <option  value="5’2” 157.48cm">5’2” 157.48cm</option>
         <option  value="D5’3” 160.02cm">5’3” 160.02cm</option>
        <option  value="5’4” 162.56cm">5’4” 162.56cm </option>
         <option  value="5’5” 165.10cm">5’5” 165.10cm</option>
         <option  value="5’6” 167.74cm">5’6” 167.74cm</option>
          <option  value="5’7” 170.18cm">5’7” 170.18cm</option>
          <option  value="5’8” 172.72cm">5’8” 172.72cm</option>
          <option  value="5’9” 175.26cm">5’9” 175.26cm</option>
          <option  value="5’11” 180.34cm">5’11” 180.34cm</option>
          <option  value="6’0” 182.88cm">6’0” 182.88cm</option>
          <option  value="6’1” 185.45cm">6’1” 185.45cm</option>
          <option  value="6’2” 187.96cm">6’2” 187.96cm</option>
          <option  value="6’3” 190.50cm">6’3” 190.50cm</option>
          <option  value="6’4” 193.04cm">6’4” 193.04cm</option>
          <option  value="6’5” 195.58cm">6’5” 195.58cm</option>
           <option  value="6’6” 198.12cm">6’6” 198.12cm</option>
            <option  value="6’7” 200.66cm">6’7” 200.66cm</option>
             <option  value="6’8” 203.20cm">6’8” 203.20cm</option>
              <option  value="6’9” 205.74cm">6’9” 205.74cm</option>
               <option  value="6’10” 208.28cm">6’10” 208.28cm</option>
                <option  value="6’11” 210.82cm">6’11” 210.82cm</option>
                 <option  value="7’0” 213.36cm">7’0” 213.36cm</option>
                 <option  value="7’1” 215.90cm">7’1” 215.90cm</option>
                 <option  value="7’2” 218.44cm">7’2” 218.44cm</option>
      </select>
        </div>
          </div>
        </div>
       
           </div>


           <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Body type</label>
          <select name="religion">
             <option value="">-- select one --</option>
            
             <option value="Does Not Matter">Does Not Matter</option>
             <option value="Average">Average</option>
             <option value="Slim/Curvy">Slim/Curvy</option>
             <option value="Athletic">Athletic</option>
             <option value="Muscular">Muscular</option>
             <option value="Slim/Curvy">Slim/Curvy</option>
             <option value="Few extra pounds">Few extra pounds</option>
             <option value="Overweight">Overweight</option>
          </select>

          </div>
    </div>
    <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Eye Color</label>
          <select name="eye-color">
            <option>Black</option>
             <option>Blue</option>
            <option>Brown</option>
            <option>Gray</option>
            <option>Green</option>
            <option>Hazel</option>
         <option>Other</option>
            </select>
          </div>
    </div>
              </div>
              <div class="row">
                <div class="col-4">
       <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Hair Color</label>
        <select>
         <option>Brown</option>
         <option>Black</option>
         <option>White</option>
         <option>Sandy</option>
         <option>Gray or Partially Gray</option>
         <option>Red/Auburn</option>
         <option>Blond</option>
         <option>Blue</option>
         <option>Green</option>
         <option>Orange</option>
         <option>Pink</option>
         <option>Purple</option>
         <option>Partly or Completely Bald</option>
          <option>Chestnut</option>
        </select>
          </div>
    </div>
    <div class="col-4">
 
            <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Zodiac Sign</label>
          <select>
           <option value="Aries">Aries</option>
           <option  value="Taurus">Taurus</option>
           <option  value="Gemini">Gemini</option>
           <option  value="Cancer">Cancer</option>
          <option  value="Virgo">Virgo</option>
          <option  value="Libra">Libra</option>
          <option  value="Scorpio">Scorpio</option>
          <option  value="Sagittarius">Sagittarius</option>
          <option  value="Capricorn">Capricorn</option>
    </select>
          </div>
        </div>
         <div class="col-4">
       <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Profession</label>
           <select  id="occupation" name="occupation">
         <option value="" selected="selected" disabled="disabled">-- select one --
        </option>

         <option value="1">- Chiropractor</option>
         <option value="2">- Dentist</option>
         <option value="3">- Dietitian or Nutritionist</option>
         <option value="4">- Optometrist</option>
         <option value="5">- Pharmacist</option>
         <option value="6">- Physician</option>
         <option value="7">- Physician Assistant</option>
         <option value="8">- Podiatrist</option>
         <option value="9">- Registered Nurse</option>
         <option value="10">- Therapist</option>
         <option value="11">- Veterinarian</option>
         <option value="12">- Health Technologist or Technician</option>
         <option value="13">- Other Healthcare Practitioners and Technical
        Occupation</option>
         </optgroup>
         <optgroup label="Healthcare Support Occupations:">
         <option value="14">- Nursing, Psychiatric, or Home Health Aide</option>
         <option value="15">- Occupational and Physical Therapist Assistant or
        Aide</option>
         <option value="16">- Other Healthcare Support Occupation</option>
         </optgroup>
         <optgroup label="Business, Executive, Management, and Financial
        Occupations:">
         <option value="17">- Chief Executive</option>
         <option value="18">- General and Operations Manager</option>
         <option value="19">- Advertising, Marketing, Promotions, Public
        Relations, and Sales Manager</option>
         <option value="20">- Operations Specialties Manager (e.g., IT or HR
        Manager)</option>
         <option value="21">- Construction Manager</option>
         <option value="22">- Engineering Manager</option>
         <option value="23">- Accountant, Auditor</option>
         <option value="24">- Business Operations or Financial
        Specialist</option>
         <option value="25">- Business Owner</option>
         <option value="26">- Other Business, Executive, Management, Financial
        Occupation</option>
         </optgroup>
         <optgroup label="Architecture and Engineering Occupations:">
         <option value="27">- Architect, Surveyor, or Cartographer</option>
         <option value="28">- Engineer</option>
         <option value="29">- Other Architecture and Engineering
        Occupation</option>
         </optgroup>
         <optgroup label="Education, Training, and Library Occupations:">
         <option value="30">- Postsecondary Teacher (e.g., College
        Professor)</option>
         <option value="31">- Primary, Secondary, or Special Education School
        Teacher</option>
         <option value="32">- Other Teacher or Instructor</option>
         <option value="33">- Other Education, Training, and Library
        Occupation</option>
         </optgroup>
         <optgroup label="Other Professional Occupations:">
         <option value="34">- Arts, Design, Entertainment, Sports, and Media
        Occupations</option>
         <option value="35">- Computer Specialist, Mathematical Science</option>
         <option value="36">- Counselor, Social Worker, or Other Community and
        Social Service Specialist</option>
         <option value="37">- Lawyer, Judge</option>
         <option value="38">- Life Scientist (e.g., Animal, Food, Soil, or
        Biological Scientist, Zoologist)</option>
         <option value="39">- Physical Scientist (e.g., Astronomer, Physicist,
        Chemist, Hydrologist)</option>
         <option value="40">- Religious Worker (e.g., Clergy, Director of
        Religious Activities or Education)</option>
         <option value="41">- Social Scientist and Related Worker</option>
         <option value="42">- Other Professional Occupation</option>
         </optgroup>
         <optgroup label="Office and Administrative Support Occupations:">
         <option value="43">- Supervisor of Administrative Support
        Workers</option>
         <option value="44">- Financial Clerk</option>
         <option value="45">- Secretary or Administrative Assistant</option>
         <option value="46">- Material Recording, Scheduling, and Dispatching
        Worker</option>
         <option value="47">- Other Office and Administrative Support
        Occupation</option>
         </optgroup>
         <optgroup label="Services Occupations:">
         <option value="48">- Protective Service (e.g., Fire Fighting, Police
        Officer, Correctional Officer)</option>
         <option value="49">- Chef or Head Cook</option>
         <option value="50">- Cook or Food Preparation Worker</option>
         <option value="51">- Food and Beverage Serving Worker (e.g., Bartender,
        Waiter, Waitress)</option>
         <option value="52">- Building and Grounds Cleaning and
        Maintenance</option>
         <option value="53">- Personal Care and Service (e.g., Hairdresser,
        Flight Attendant, Concierge)</option>
         <option value="54">- Sales Supervisor, Retail Sales</option>
         <option value="55">- Retail Sales Worker</option>
         <option value="56">- Insurance Sales Agent</option>
         <option value="57">- Sales Representative</option>
         <option value="58">- Real Estate Sales Agent</option>
         <option value="59">- Other Services Occupation</option>
         </optgroup>
         <optgroup label="Agriculture, Maintenance, Repair, and Skilled Crafts
        Occupations:">
         <option value="60">- Construction and Extraction (e.g., Construction
        Laborer, Electrician)</option>
         <option value="61">- Farming, Fishing, and Forestry</option>
         <option value="62">- Installation, Maintenance, and Repair</option>
         <option value="63">- Production Occupations</option>
         <option value="64">- Other Agriculture, Maintenance, Repair, and
        Skilled Crafts Occupation</option>
         </optgroup>
         <optgroup label="Transportation Occupations:">
         <option value="65">- Aircraft Pilot or Flight Engineer</option>
         <option value="66">- Motor Vehicle Operator (e.g., Ambulance, Bus,
        Taxi, or Truck Driver)</option>
         <option value="67">- Other Transportation Occupation</option>
         </optgroup>
         <optgroup label="Other Occupations:">
         <option value="68">- Military</option>
         <option value="69">- Homemaker</option>
         <option value="70">- Other Occupation</option>
         <option value="71">- Don't Know</option>
         <option value="72">- Not Applicable</option>
            
          </select>

          </div>
          </div>
              </div>

              <div class="row">
                  <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Children</label>
          <select name="religion">
             <option value="">-- select one --</option>
            
             <option value="Does Not Matter">Does Not Matter</option>
             <option value="No<">No</option>
             <option value="Yes, any age<">Yes, any age</option>
             <option value="Yes, 1-4 years">Yes, 1-4 years</option>
             <option value="Muscular">Yes, 5-8 years</option>
             <option value="Slim/Curvy">Yes, 9-15 yearsy</option>
             <option value="Few extra pounds">Yes, 16 -20 years</option>
             <option value="Overweight">Yes. 21 and up</option>

            
          </select>

          </div>
    </div>
    <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Body type</label>
          <select name="religion">
             <option value="">-- select one --</option>
            
             <option value="Does Not Matter">Does Not Matter</option>
             <option value="Average">Average</option>
             <option value="Slim/Curvy">Slim/Curvy</option>
             <option value="Athletic">Athletic</option>
             <option value="Muscular">Muscular</option>
             <option value="Slim/Curvy">Slim/Curvy</option>
             <option value="Few extra pounds">Few extra pounds</option>
             <option value="Overweight">Overweight</option>

            
          </select>

          </div>
    </div>
    <div class="col-4">
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Relationship Status</label>
          <select name="religion">
             <option value="">-- select one --</option>
            
             <option value="Does Not Matter">Does Not Matter</option>
             <option value="Never Married">Never Married</option>
             <option value="Divorce">Divorce</option>
             <option value="Widowed">Widowed</option>
             <option value="Pending Divorce">Pending Divorce</option>
            
          </select>

          </div>
    </div>
          
              </div>

              <div class="row">
    <div class="col-4">
       <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Education</label>
        <select>
         <option>Does Not Matter</option>
         <option>Secondary/High School</option>
         <option>Vocational/Technical School</option>
         <option>College/Bachelors</option>
         <option>Gray or Partially Gray</option>
         <option>University/Masters </option>
         <option>University/Doctorate/</option>
         <option>University Post Doctorate</option>
       
        </select>
          </div>
    </div>
    <div class="col-4">
       <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Smoking</label>
        <select>
         <option value="Does Not Matter">Does Not Matter</option>
         <option  value="HATE THE SMELL">HATE THE SMELL</option>
         <option  value="SOCIABLE">SOCIABLE</option>
         <option  value="RECENTLY QUIT">RECENTLY QUIT</option>
        <option  value="NEVER SMOKED">NEVER SMOKED </option>
         
      
      </select>
          </div>

    </div>
    <div class="col-4">
      
      <div class="form-group" style="margin-bottom: 3rem;">
          <label for="email">Alcohol use</label>
          <select name="">
             <option value="Does Not Matter">Does Not Matter</option>
         <option  value="YES">YES</option>
         <option  value="NO NEVER">NO NEVER</option>
         <option  value="RECENTLY QUIT">SOCIABLE</option>
        <option  value="NEVER SMOKED">OCCASSIONALLY</option>
              </select>
    </div>
    </div>

  </div>





               <input type="submit" name="submit" value="&nbsp;&nbsp;Show your matches&nbsp;&nbsp;" class="blue-bc">
        </form>

        
      </div>
      </div>

    </div>
          

<script>  
  // for search modal
  $('#search_modal_myBtn').on('click', function(){
    

    $('#search_modal').show();
  });
  
  $('.search_modal_close').on('click', function(){
    $('#search_modal').hide();
  });
  
</script> 
  
 <section class="what-happening-world">
   
        <div class="row">
                <div class="col-md-3 beside-img">
                
    
      <a href="#" class="d-block mb-4 h-100">
           <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/g1.gallery" alt="">
          </a>
  
</div>
<div class="col-md-3 beside-img">
      <a href="#" class="d-block mb-4 h-100">
          <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/g2.gallery" alt="">
          </a>
    </div>
<div class="col-md-3 beside-img">
   
      <a href="https://dev.mynewbride.com/page/prifile-section" class="d-block mb-4 h-100" onclick="window.open('https://dev.mynewbride.com/page/prifile-section','_self')">
            <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/profile-1.png" alt="">
          </a>
    
</div>    
                <div class="col-md-3 box-img" >
                <div class="wht-happend-inner">   
                <h1>Whats Happening In Your World</h1>    
                <ul>
                <li><a class="w-href" href="https://dev.mynewbride.com/page/SEND-FLOWERS" onclick="window.open('https://dev.mynewbride.com/page/SEND-FLOWERS','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-1.jpg" alt=""></span>Send Flowers </a></li>   
                <li><a class="w-href" href="https://dev.mynewbride.com/page/gift" onclick="window.open('https://dev.mynewbride.com/page/gift','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-2.jpg" alt=""></span> Send Gift</a></li>    
                <li><a class="w-href" href="https://dev.mynewbride.com/page/new-email" onclick="window.open('https://dev.mynewbride.com/page/new-email','_self')"> <span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-3.jpg" alt=""></span>New Email</a></li>    
                <li><a class="w-href" href="https://dev.mynewbride.com/page/MEMBERS-ONLY" onclick="window.open('https://dev.mynewbride.com/page/MEMBERS-ONLY','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-4.jpg" alt=""></span> Potential  Soul Mate</a></li>
                <li><a class="w-href" href="https://dev.mynewbride.com/page/SMART-MATCHES" onclick="window.open('https://dev.mynewbride.com/page/SMART-MATCHES','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-5.jpg" alt=""></span>Smart Matches</a></li>    
                <li><a class="w-href" href="https://dev.mynewbride.com/page/MEMBERS-ONLY" onclick="window.open('https://dev.mynewbride.com/page/MEMBERS-ONLY','_self')"> <span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-6.jpg" alt=""></span>Members Online</a></li>    
                <li><a class="w-href"href="https://dev.mynewbride.com/page/VIRTUAL-GIFTSS" onclick="window.open('https://dev.mynewbride.com/page/VIRTUAL-GIFTSS','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-7.jpg" alt=""></span> Virtual Gifts</a></li>   

                <li><a class="w-href" href="https://dev.mynewbride.com/page/MUSIC-CENTER" onclick="window.open('https://dev.mynewbride.com/page/MUSIC-CENTER','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-8.jpg" height="30px" alt=""></span> Music Center</a></li>
                <li><a class="w-href" href="https://dev.mynewbride.com/page/SITE-SECURITY-" onclick="window.open('https://dev.mynewbride.com/page/SITE-SECURITY-','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-9.jpg" alt=""></span> Site Security </a></li>
                <li><a class="w-href" href="https://dev.mynewbride.com/page/NO-SCAMMERS" onclick="window.open('https://dev.mynewbride.com/page/NO-SCAMMERS','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-10.jpg" alt=""></span> No Scammers</a></li>
                <li><a class="w-href" href="https://dev.mynewbride.com/page/SITE-BLOGS" onclick="window.open('https://dev.mynewbride.com/page/SITE-BLOGS','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-11.jpg" alt=""></span> Site Bloges</a> </li>
                <li><a class="w-href" href="https://dev.mynewbride.com/page/NEWS" onclick="window.open('https://dev.mynewbride.com/page/NEWS','_self')"><span><img src="/inc/templates/<?=D_TEMP ?>/images/new_images/world-img-12.jpg" alt=""></span>News</a></li>
                </ul>
                </div>     
            </div>
        </div>
    
</section>   
<section class="what-happening-world whatsh-gap">
 
        <div class="row">
                <div class="col-md-3 beside-img">
                
    
      <a href="#" class="d-block mb-4 h-100">
           <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/g1.gallery" alt="">
          </a>
  
</div>
<div class="col-md-3 beside-img">
      <a href="#" class="d-block mb-4 h-100">
          <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/g2.gallery" alt="">
          </a>
    </div>
<div class="col-md-3 beside-img">
   
      <a href="#" class="d-block mb-4 h-100">
            <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/profile-1.png" alt="">
          </a>
    
</div>    
                <div class="col-md-3 beside-img" >
               
      <a href="#" class="d-block mb-4 h-100">
          <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/profile-2.png" alt="">
          </a>
   
     </div>
</section>  
<!-- <div class="container page-hide">

  
  <hr class="mt-2 mb-5">

  <div class="row text-center text-lg-left">

    <div class="col-lg-3 col-md-4 col-6">
      <a href="https://dev.mynewbride.com/page/prifile-section" class="d-block mb-4 h-100">
           <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-1.jpg" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="https://dev.mynewbride.com/page/prifile-section" class="d-block mb-4 h-100">
          <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-2.jpg" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="https://dev.mynewbride.com/page/prifile-section" class="d-block mb-4 h-100">
            <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-4.jpg" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="https://dev.mynewbride.com/page/prifile-section" class="d-block mb-4 h-100">
           <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/img-footer-5.jpg" alt="">         </a>
    </div>
    
    </div>
     </div>
 --><section class="send-here-flower page-hide">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="flowe-inner">
                <img src="/inc/templates/<?=D_TEMP ?>/images/new_images/image-flower.jfif" alt="">
                <h6>ARE YOU SHY, OR JUST WANT TO LET HER KNOW THAT YOU’RE ATTRACTED TO HER? GO AHEAD AND TAKE THE FIRST STEP!</h6>
                <button type="button" class="send-here">Send Her Flowers</button>    
                </div>
            </div>
        </div>
    </div>
</section>  


<? } else {
  
if($_SERVER['REQUEST_URI']!='/' && $page!='index'){

  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
  <title><?=$HEADER_META_TITLE ?></title>
    <meta name="keywords" content="<?=$HEADER_META_KEYWORDS ?>" />
    <meta name="description" content="<?=$HEADER_META_DESCRIPTION ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=<?=$HEADER_META_CHARSET ?>">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <?=$HEADER_META_BASE ?>
    <?php e_meta(); ?>
    <?=(isset($HEADER_ANALYTICS)) ? $HEADER_ANALYTICS : "";?>

    <?php require_once __DIR__ .'/../layout/header_scripts.php' ?>
</head>

<style type="text/css">
.language {
    outline: none;
    border: 1px solid #00b900;
    width: 100px;
    margin-right: 15px;
    padding: 3px 0px;
    font-size: 12px;
    color: #ff5e00;
}    
.right-nav-images img {
    display: inline-block;
    width: 110px;
    padding: 0 10px;
    margin-top: 47px;
}    
.right-nav-images {
    float: right;
    width: auto;
}    
.logo-images-nav img.logo-width {
    width: 160px;
    float: left;
}    
.logo-images-nav {
    padding: 20px 20px;
    float: left;
    width: 100%;
}    
div#page_container {
    border: none;
    display: table;
  /*  margin: 0 auto;*/
    float: none;
    padding-bottom: 0 !important;
}
.back-full-header {
    background-color: #fff;
    float: left;
    width: 100%;
}    
.yellow-navbar {
    padding: 10px 20px;
    background-color: #00b900;
    float: left;
    width: 100%;
}
.yellow-navbar ul {
    float: left;
    width: 100%;
    list-style: none;
    padding: 0;
    margin: 0;
}
.yellow-navbar ul li a {
    margin: 0;
    float: left;
    width: auto;
    padding: 7px 24px;
    color: #ffff;
    font-size: 15px;
    font-weight: 600;
}    
.yellow-navbar ul li {
    float: left;
    width: auto;
}
.yellow-navbar ul li {
    float: left;
    width: auto;
}    
#MenuControlMain {
    margin-bottom: 20px;
    float: left;
    width: 100%;
    padding: 1px;
    border: 1px solid #C8C8C8;
    border-radius: 5px;
    border-top-right-radius: 5px;
    border-bottom-right-radius: 0px;
    border-right: 1px #ccc solid;
}
#basic_search ul.details .first {
    color: #ff5e00 !important;
}    
.gallery_search.highlighted2 {
    margin-bottom: 10px;
}       
div.my_tasklist ul.dropdown-menu, button.btn.btn-primary.dropdown-toggle.dropmenus {
    border: 1px solid #ff5e00 !important; 
}    
#MenuControlBot a {
    color: #ff5e00;
    margin-left: 10px;
}
div#MenuControlHead {
    background-color: #f8f8f8 !important;
}    
div#MainPageBackground .navbar.navbar-fixed-top.navbar-boxed div#PageHeader {
    background-color: #00b900 !important;
}    
#side_box .menu_box_title, .menu_box_title1 {
    border: 1px solid #ccc!important;
    background: #fff;
    font-size: 15px;
    display: block;
    padding: 3px 10px 7px 14px;
    height: 18px;
    overflow: hidden;
    font-weight: bold;
    line-height: 39px!important;
    min-height: 45px;
    border-radius: 5px 5px 0 0;
    border-bottom: none;
    color: var(--template-color);
    border-bottom: 0!important;
    background-color: #f8f8f8 !important;
}    
#fullpage #side_box {
    margin-top: 15px;
    background-color: transparent;
}    
.user-general-info-sidebar .user-general-info-sidebar-desc {
    float: left;
    width: 100%;
    background: #FFFFFF;
    border: 1px solid #c4c4c4;
    padding: 10px 0px;
    border-right: 1px solid #c4c4c4;
    text-align: center;
}    
.user-general-info-sidebar .user-general-info-sidebar-desc .sidebar_membership {
    padding: 0 15px;
}
#overview-account-box .account_profile_completion {
    background: #fafafa;
    border-radius: 2px;
    float: left;
    padding: 20px 10px;
    margin: 15px 0;
}    
#overview-account-box .account_profile_completion .profile_photo {
    margin-top: 10px;
}    
a.editor_cancel_link.editor_cancel {
    margin-left: 10px;
}    
#MainPageBackground .wide_wrapper div#page_container {
    border: none;
    padding: 15px 0 15px 20px;
}    
div#PageHeader, .message-bad, div#ProfileUsernameBox, #Profile_MainBar #ShowProfileData .profile_box_body p a, .category-list.clearfix .inner_nav_bar, .navbar.navbar-inverse.navbar-fixed-top, #NewAlertsBar span.alert_msg_outspan, #eMeeting .account_tabs li.selected, .header.account_tabs li:hover, A.MainBtn:hover, input.MainBtn:hover, A.NormBtn, input.NormBtn, A.NormBtn:hover, input.NormBtn:hover, A.MainBtn, input.MainBtn, ul.form input.MainBtn, table.map_table tr[bgcolor="#999999"], body #PageHeader, .inner_nav_bar, .map_seprator, .navbar-toggle:hover .icon-bar, #fullpage .navbar-toggle .icon-bar, #PageHeader .navbar-toggle .icon-bar, div#mynav, .nav_button, .user-general-info-sidebar .user-general-info-sidebar-user, #overview-profile-complete .completed, .background_color, .background_color:before, .background_color:after, .compatibility_main .form-compatibility .heading, .compatibility_main .action-button, p.page_decr, .compatibility_main .next-btn, .compatibility_main .back-btn {
   /* background-color: #ff5e00!important;*/
}    
.overview-compatibility-section .border_color {
    border-color: #ff5e00!important;
}    
.header.account_tabs ul li a {
    width: 100%;
    padding: 0 20px;
    margin: 0;
    color: #666;
}  
#overview-profile-complete p {
    color: #000;
}    
#eMeeting .account_tabs{
    width: 100%;
    padding: 0 20px 0 0;
    margin: 0;
    color: #666;    
}    
.profile_box_title .goR a, .galleryviewleft b, .profile_box_title .goL h1, .groupInfoContainer b a, #side_box .menu_box_title, .menu_box_title1, button.btn.btn-primary.dropdown-toggle.dropmenus, .inner_common_cont h3, #page_container a.mhlinkred, #page_container a.mhlinkred:visited, .registration-container h2, .registration-container h3, .registration-container label, #profile_section_13 .tab li.active, #eMeeting .menu_tab li.active a, #eMeeting .menu_tab li a:hover, #profile_section_13 .profile_question span, #fullpage div#quick-search .head-title, .user-general-info-sidebar .user-general-info-sidebar-desc .sidebar_membership span, .template_color, .compatibility_main ul.form li.question .pink {
    color: #ff5e00!important;
}    
.overview-compatibility-section .compatibility-content {
    color: #FFF;
    text-align: center;
    padding: 12px 10px 10px 10px;
    background-color: #ff5e00!important;
}
div#overview-profile-complete span.completed {
    background-color: #ff5e00!important;
}    
.side_left_blog .user-general-info-sidebar-user {
    background-color: #ff5e00 !important;
}    
#fullpage .overviewOptions a.mhlinks2 {
    color:#ff5e00!important;
}    
.profile_box_title .goR a, .galleryviewleft b, .profile_box_title .goL h1, .groupInfoContainer b a, #side_box .menu_box_title, .menu_box_title1, button.btn.btn-primary.dropdown-toggle.dropmenus, .inner_common_cont h3, #page_container a.mhlinkred, #page_container a.mhlinkred:visited, .registration-container h2, .registration-container h3, .registration-container label, #profile_section_13 .tab li.active, #eMeeting .menu_tab li.active a, #eMeeting .menu_tab li a:hover, #profile_section_13 .profile_question span, #fullpage div#quick-search .head-title, .user-general-info-sidebar .user-general-info-sidebar-desc .sidebar_membership span, .template_color, .compatibility_main ul.form li.question .pink {
    color: #ff5e00!important;
}   
div#PageHeader, .message-bad, div#ProfileUsernameBox, #Profile_MainBar #ShowProfileData .profile_box_body p a, .category-list.clearfix .inner_nav_bar, .navbar.navbar-inverse.navbar-fixed-top, #NewAlertsBar span.alert_msg_outspan, #eMeeting .account_tabs li.selected, .header.account_tabs li:hover, A.MainBtn:hover, input.MainBtn:hover, A.NormBtn, input.NormBtn, A.NormBtn:hover, input.NormBtn:hover, A.MainBtn, input.MainBtn, ul.form input.MainBtn, table.map_table tr[bgcolor="#999999"], body #PageHeader, .inner_nav_bar, .map_seprator, .navbar-toggle:hover .icon-bar, #fullpage .navbar-toggle .icon-bar, #PageHeader .navbar-toggle .icon-bar, div#mynav, .nav_button, .user-general-info-sidebar .user-general-info-sidebar-user, #overview-profile-complete .completed, .background_color, .background_color:before, .background_color:after, .compatibility_main .form-compatibility .heading, .compatibility_main .action-button, p.page_decr, .compatibility_main .next-btn, .compatibility_main .back-btn {
    /*background-color: #ff5e00 ;*/

}
#side_box .menu_box_title, .menu_box_title1 {
    border: 1px solid #cccccc !important;
    background: #fff;
    font-size: 15px;
    display: block;
    padding: 3px 10px 7px 14px;
    height: 18px;
    overflow: hidden;
    font-weight: bold;
    line-height: 39px !important;
    min-height: 45px;
    border-radius: 5px 5px 0px 0px;
    border-bottom: none;
    color: var(--template-color);
    border-bottom: 0 !important;
}    
#MainPageBackground .wide_wrapper div#page_container {
    background-color: #fff !important;
}    
#PageHeader .sub_menu {
    width: 100%;
    min-height: 52px;
    background-color: #000!important;
    -moz-box-shadow: 0 3px 7px #c1c1c3;
    -webkit-box-shadow: 0 3px 7px #c1c1c3;
    -khtml-box-shadow: 0 3px 7px #c1c1c3;
    box-shadow: 0 3px 7px #c1c1c3;
    margin: 0 0 0 0;
}
    #fullpage div#main {
    width: 98%;
    background-color: #fff;
}
    .four-col li h1 {
    margin-top: 10px;
    margin-bottom: 10px;
}
div#MenuBar {
    background: #ff5e00 !important;
    margin: 0 auto;
    padding: 0 0px 0px 13px;
    width: 100%;
}
div#MenuBar ul li a {
    color: #000 !important;
}
.sub_tabs li a {
    color: #000 !important;
}
div#myModal .modal-content .column{
width: 50%;
text-align: center;
border-right: 1px #ccc solid;
}
div#myModal .modal-content .column:last-child {
border-right: 0;
}
.header .background-color-top .col-md-12 {
   margin-left: 0 !important;
}
.header .background-color-top .col-md-12 nav.navbar.navbar-expand-sm {
   padding-left: 0 !important;
}

</style>
<? if(isset($HEADER_SINGLE_COLUMN)){ ?>
<body id="splitpage" <?=$HEADER_ON_LOAD ?>>
<? }else{ ?>
<body id="fullpage" <?=$HEADER_ON_LOAD ?>>
<? } ?>
<?php e_head(); ?>


<div id="MainPageBackground">

    <?php
   if($_SESSION['auth'] == 'no')
   {
    ?>

    <div <?php if($page != "index"){?> class="navbar navbar-inverse "<?php }?> >

        <div class="page_header" id="PageHeader" >
            <!--style="background-color: #ff5e00 !important;"-->
             <?php if($page != "index")
       {
       ?>
                <div class="logo_height">
                    <a href="<?=DB_DOMAIN ?>index.php" title="<?=$HEADER_META_TITLE ?>">
                        <div id="ImageLogo">          
                            <p class="<? if( TMP_LOGO_ICON =="images/DEFAULT/LOGOS/none.png"){ print "p3"; }else{ print "p1"; } ?>"><? if(TMP_LOGO_HIDE ==0){ ?><?=TMP_LOGO ?><? } ?></p>         
                            <p class="p2"><? if(TMP_LOGO_HIDE ==0){ ?><?=TMP_LOGO_SLOGAN ?><? } ?></p>
                        </div>
                    </a>
                </div>

      <?php
             }
            ?>
            <style type="text/css">
                div#MainPageBackground .navbar.navbar-inverse {
                    background-color: #000!important;
                    border-radius: 0px !important;
                }
                   .w-content {
                  padding-top: 60px;
                  font-size: 54px;
                  font-weight: bold;
                  margin-left: 1px;
                  background-color: #000!important;
                  background-color: #fff;
                  color: #ffc202!important;
               }
                  .w-r-c {
                  color: red;
                  background-color: #000;
                  font-size: 26px;
                  font-weight: bold;
                  text-align: center;
                  padding: 0 365px 0 0;
               }
                div#PageHeader .right-head {
                    padding: 33px 170px 20px 10px;
                    /*margin: -133px -118px 13px -5px;*/
                    margin: -118px 0px -5px 0px;
                }
                body #eMeeting .account_tabs li.selected {
                    background: #ffc202!important;
                    border: #ffc202!important;
                }
                ul.form .CapBody li input.MainBtn {
                    background: #ffc202!important;
                }
            </style>
            <div class="w-content">Welcome To MyNewBride</div><div class="w-r-c">Your place to find your soul mate</div>
            <div class="right-head" style=" <?php if($page == "index"){?> margin:21px 20px 0px 0px; <?php } ?>">
            <!--4-->
        <?php

                if(isset($_SESSION['lang'])){
                    $lang = $_SESSION['lang'];
                    $$lang = "selected = 'selected'";
                }
                else{
                    $english = "selected = 'selected'";
                }

                
                ?>
                <form class="f_left">
                    <select class="language f_left padding_5" name="lang" id="lang" onchange="location = this.options[this.selectedIndex].value;"> 
                        <option value="/index.php?l=english" <?php if(isset($english)){ echo $english;}?>>English</option>
                        <option value="/index.php?l=bosnian" <?php if(isset($bosnian)){ echo $bosnian;}?>>Bosnian</option>
                        <option value="/index.php?l=turkey" <?php if(isset($turkey)){ echo $turkey;}?>>Turkey</option>
                        <option value="/index.php?l=spanish" <?php if(isset($spanish)){ echo $spanish;}?>>Spanish</option>
                        <option value="/index.php?l=russian" <?php if(isset($russian)){ echo $russian;}?>>Russian</option>
                        <option value="/index.php?l=czech" <?php if(isset($czech)){ echo $czech;}?>>Czech</option>
                        <option value="/index.php?l=japanese" <?php if(isset($japanese)){ echo $japanese;}?>>Japanese</option>
                        <option value="/index.php?l=slovenian" <?php if(isset($slovenian)){ echo $slovenian;}?>>Slovenian</option>
                        <option value="/index.php?l=swedish" <?php if(isset($swedish)){ echo $swedish;}?>>Swedish</option>
                        <option value="/index.php?l=slovak" <?php if(isset($slovak)){ echo $slovak;}?>>Slovak</option>
                        <option value="/index.php?l=thai" <?php if(isset($thai)){ echo $thai;}?>>Thai</option>
                        <option value="/index.php?l=danish" <?php if(isset($danish)){ echo $danish;}?>>Danish</option>
                        <option value="/index.php?l=chinese" <?php if(isset($chinese)){ echo $chinese;}?>>Chinese</option>
                        <option value="/index.php?l=romanian" <?php if(isset($romanian)){ echo $romanian;}?>>Romanian</option>
                        <option value="/index.php?l=german" <?php if(isset($german)){ echo $german;}?>>German</option>
                        <option value="/index.php?l=italian" <?php if(isset($italian)){ echo $italian;}?>>Italian</option>
                        <option value="/index.php?l=vietnamese" <?php if(isset($vietnamese)){ echo $vietnamese;}?>>Vietnamese</option>
                        <option value="/index.php?l=arabic" <?php if(isset($arabic)){ echo $arabic;}?>>Arabic</option>
                        <option value="/index.php?l=portugues" <?php if(isset($portugues)){ echo $portugues;}?>>Portugues</option>
                        <option value="/index.php?l=norwegian" <?php if(isset($norwegian)){ echo $norwegian;}?>>Norwegian</option>
                        <option value="/index.php?l=dutch" <?php if(isset($dutch)){ echo $dutch;}?>>Dutch</option>
                        <option value="/index.php?l=korean" <?php if(isset($korean)){ echo $korean;}?>>Korean</option>
                        <option value="/index.php?l=croatian" <?php if(isset($croatian)){ echo $croatian;}?>>Croatian</option>
                        <option value="/index.php?l=taiwanese" <?php if(isset($taiwanese)){ echo $taiwanese;}?>>Taiwanese</option>
                        <option value="/index.php?l=polish" <?php if(isset($polish)){ echo $polish;}?>>Polish</option>
                        <option value="/index.php?l=french" <?php if(isset($french)){ echo $french;}?>>French</option>
                        <option value="/index.php?l=greek" <?php if(isset($greek)){ echo $greek;}?>>Greek</option>
                    </select>
                  <? if(my_logged_in){ ?>
           <? }elseif($page == "index"){ ?>
                        <a href="/index.php?dll=login" style="text-decoration:none; background-color:white; margin-left:18px; padding: 5px 14px; line-height: 25px;">
                            Login Here
                        </a>
                    <? } ?>
                </form>
                
                <div style="display:none;" class="login-top">
                <div class="content-width">
                <div class="login-box">
                    <form method="post" action="<?=DB_DOMAIN ?>index.php" name="LoginForm" onSubmit="return CheckNullsLogin('<?=$GLOBALS['_LANG_ERROR']['_incomplete'] ?>');">
                    <input name="do" type="hidden" value="login" class="hidden">
                    <input name="visible" value="0" type="hidden">
                    <input name="do_page" type="hidden" value="login" class="hidden">
                
                    <ul class="form custom-border">   
                 
                    <div class="CapBody">   
                
                <? if (defined('FACEBOOK_APP_ID')  && FACEBOOK_APP_ID !="") { ?>             
                <li>
                 <a class="btn-ragister" href="<?=DB_DOMAIN ?>index.php?dll=fblogin"><img src="/inc/templates/<?=D_TEMP ?>/images/facebook-f.jpg" />Login Fast with facebook</a><br />
                </li>
                <? } ?>
                <li>
                    
                    <div class="line-txt"><span>or sign in below</span></div></li>    
                        <li><input placeholder="<?=$GLOBALS['_LANG']['_username'] ?>" tabindex="1" maxlength="15" name="username" id="e_username" type="text" class="input" size="25" <? if(isset($_COOKIE['emeeting']['username'])){ print "value='".$_COOKIE['emeeting']['username']."'"; } ?>>
                        </li>
                        <li><input placeholder="<?=$GLOBALS['_LANG']['_password'] ?>" tabindex="2" maxlength="25" name="password" id="e_password" type="password" class="input" size="25"></li>
                        <? if(D_REGISTER_IMAGE ==1){ ?>
                
                        <? } ?>
                        <li><input class="green-btn" maxlength="15" type="submit"  value="<?=$GLOBALS['_LANG']['_login'] ?>" class="MainBtn"></li>
                        <!--<li><input type="checkbox" name="remember" value="1" style="margin-right:15px;" checked='checked'><?=$GLOBALS['_LANG']['_rememberMe']  ?></li>-->
                        <li class="forget-txt"><a href="#" onclick="toggleLayer('ForgottenPassword2'); return false;"><?=$GLOBALS['LANG_COMMON'][1] ?></a></li>
                    <?php /*?>  <? if(VALIDATE_EMAIL==1){ ?>
                        <li><img src="<?=DB_DOMAIN ?>images/DEFAULT/_acc/emoticon_smile.png" align="absmiddle"> <a href="#" onclick="toggleLayer('ActAccount'); return false;"><?=$GLOBALS['LANG_LOGIN']['a7'] ?></a></li>
                        <? } ?><?php */?>
                        </div>
                    </ul>
                    </form> 
                    <div style="display:none" id="ForgottenPassword2">  
                        <form method="post" action="<?=DB_DOMAIN ?>index.php" name="ForgotPassword">
                        <input name="do" type="hidden" value="password" class="hidden">
                        <input name="do_page" type="hidden" value="login" class="hidden">
                        <input name="username" type="hidden" value="" class="hidden">
                        <ul class="form forget-form">   
                        <div class="CapBody"><li>Enter your registration email<br /> and we'll send your a password</li>
                            <li><input maxlength="150" name="email" type="text" size="20" class="input"></li>
                            <?php /*?><? if(D_REGISTER_IMAGE ==1){ ?><li><label ><?=$GLOBALS['_LANG']['_verification'] ?>:</label> <input maxlength="15" type="text" name="code" id="C4" class="input"><br><img name="Verification Image" src="<?=DB_DOMAIN ?>inc/classes/class_regimg_img.php?regen=y&<? echo time(); ?>"></li><? } ?><?php */?>
                            <li><input class="green-btn" type="submit"  value="<?=$GLOBALS['_LANG']['_submit'] ?>" class="MainBtn"></li>
                        </div>
                        </ul>
                        </form>
                    </div>
                </div>
                </div>
                </div>
                <!--4-->
            </div>  
                
             <?php if($page != "index")
       {
       ?>
                <div id="top_banner" class="hiddenonsmall"><? foreach($BANNER_ARRAY as $banner){ if($banner['position'] =="top"){ print $banner['display'];}} ?></div>   
            <?php
             }
            ?>
            
            
            <div class="nav_button hidden-lg hidden-md">
              <span style="padding-left:12px;">
            <span>
                      <a href="<?=DB_DOMAIN ?>index.php?dll=search&page=1&online=1" style="color:#fff;">
              <?=CountOnline() ?> <?=$GLOBALS['_LANG']['_members']." ".$GLOBALS['_LANG']['_online'] ?>
                         </a>
                    </span>
          </span> 
               <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynav">
                 <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
            </button>
            </div>
            <div class="" id="MenuBar" style=" <?php if($page == "index"){?> margin:21px 20px 0px 0px; <?php } ?>" ><!--3-->
          
            
            <div class="collapse navbar-collapse" id="mynav">
            
                <ul class="tabs nav navbar-nav">
                    <?=$HEADER_MENU_BAR_TOP ?>
                    <div class="hidden-md hidden-lg">
                     <?=$HEADER_MENU_BAR_SUB ?>
                     </div>
                </ul> 
                
                
                
                </div>
                    
            </div>
          
            <div class="sub_menu hidden-xs hidden-sm" style="background-color: #ff5e00 !important">
          <ul class="sub_tabs f_left">
            <?=$HEADER_MENU_BAR_SUB ?>  
          </ul>
          <span style="float:right;padding:4px;">
            <span class="onlinenow">
                      <a href="<?=DB_DOMAIN ?>index.php?dll=search&page=1&online=1">
              <?=CountOnline() ?> <?=$GLOBALS['_LANG']['_members']." ".$GLOBALS['_LANG']['_online'] ?>
                         </a>
                    </span>
          </span>     
            </div>
                
        </div>
    </div>
    <?php
    }
    else{
        ?>
    
    <style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 60%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

/* Create two equal columns that floats next to each other */
.column {
    float: left;
    width: 40%;
    padding: 41px;
    height: 235px;
    margin: 19px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

</style>
    <div id="page_container" class="page-container-boxed">
    <div class="back-full-header">
    <div class="yellow-navbar">
            <ul>                                                                         
                <li><a href="#">Home</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Search</a></li>
                <li><a href="#">My Profile</a></li>
                <li><a href="#">My Account</a></li>
                <li><a href="#">Support</a></li>
                <li><a href="#" id="myBtn">App</a></li>
                <li><a href="#">QR</a></li> 
            </ul>
        </div>
        <div class="logo-images-nav">
        <img src="/inc/templates/<?=D_TEMP ?>/images/logo-inner.jpg" class="logo-width" />
            
        <div class="right-nav-images">
        <img src="/inc/templates/<?=D_TEMP ?>/images/header-img-1.jpg" />
        <img src="/inc/templates/<?=D_TEMP ?>/images/header-img-2.jpg" />
        <img src="/inc/templates/<?=D_TEMP ?>/images/header-img-3.jpg" />
        <img src="/inc/templates/<?=D_TEMP ?>/images/header-img-4.jpg" />    
        <img src="/inc/templates/<?=D_TEMP ?>/images/header-img-1.jpg" />    
    <img src="/inc/templates/<?=D_TEMP ?>/images/header-img-2.jpg" />    
    </div>    
        </div>
        </div>
        </div>
    
    <div id="myModal" class="modal">

      <!-- Modal content -->
      <div class="modal-content">
      <span class="close">×</span>
      <div class="row">
        <div class="column">
        <h2>Click to Download</h2>
      <img style="text-align: center;width: 176px;" src="https://thumbs.dreamstime.com/t/app-store-google-play-icons-color-icons-app-store-google-play-colors-vector-illustration-145688828.jpg" >
        </div>
        <div class="column">
        <h2>Scan QR Code to download</h2>
        <img style="margin-left: 100px;
    margin-top: 20px;" id='barcode' 
            src="https://api.qrserver.com/v1/create-qr-code/?data=HelloWorld&size=100x100" 
            alt="" 
            title="HELLO" 
            width="50" 
            height="50" />
        </div>
      </div>
      </div>

    </div>
    
    <script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
    
    
    
    <?php
    }
    ?>

    <div <?php if($page != "index"){?> class="wide_wrapper" <?php } ?>>
        
        <?php echo getHeaderBreadCrumb($page, $sub_page, $LANG_HEADINGS, $LANG_BREADCRUMB); ?>

        <?php if (!empty(D_FEATURED_MEMBER_NUM)):
            $fdata = DisplayFeaturedMembersTop(D_FEATURED_MEMBER_NUM,1);
        else:
            $fdata = DisplayFeaturedMembersTop(24,1);
        endif;
        ?>
    
    <?php
        if(isset($_SESSION['auth']) && $_SESSION['auth'] =="yes" && D_FEATUREDMEMBERTOP2 == '1'){
        ?>
        <div id="featured_members" class="featured_members_<?=D_HEADER_LAYOUT?>">
            <div id="style5" style="margin-top:15px; float: left;">
            <div class="previous_button"></div><div class="container cont-slider">
                <ul> 
                    <? foreach( $fdata as $value){ ?>
                    <li><a href="<?=$value['link'] ?>"><img src="<?=$value['image'] ?>" width="96" height="96" border="0" style="cursor:pointer;"></a><br>
                    </li><? } ?>
                    

                </ul>

            </div>
            <div class="next_button"></div></div>
        </div>  
        <?php
        }
        ?>

        <div id="page_container"  class="page-container-<?=D_HEADER_LAYOUT?>">
 <?php } } ?>
  <style>
    navbar.navbar-inverse.navbar-fixed-top {
width: 80%;
position: relative;
margin: 0 auto;
}
    </style>
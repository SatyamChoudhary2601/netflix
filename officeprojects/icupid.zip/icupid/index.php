<!DOCTYPEhtmlPUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php 

?>
<html>
<head>
    <title><?=$HEADER_META_TITLE ?></title>
    <meta name="keywords" content="<?=$HEADER_META_KEYWORDS ?>" />
    <meta name="description" content="<?=$HEADER_META_DESCRIPTION ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=<?=$HEADER_META_CHARSET ?>">
   <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <?=$HEADER_META_BASE ?>
    <?php e_meta(); ?>

<style>
.phone-app-store {
    text-align: center;
}    
a.tagline.policy_modal {
    padding: 19px 30px;
    background-color: #000!important;
    width: auto;
    margin: 0 auto 27px;
    float: none;
    display: inline-block;
    color: #fc6!important;
}
.language {
    outline: none;
    border: 1px solid #08c408 !important;
    width: 100px;
    margin-right: 15px;
    padding: 3px 0px;
    font-size: 12px;
    color: #ffc202!important;
}
.four-col h1 {
    color:#242424 !important;
    font-size: 20px;
}    
.ui-slider-tab-content p {
    color: #434549 !important;
}    
ul.icon-list li a {
    color: #08c408 !important;
    text-decoration: none;
    font-weight: 600;
}
ul.icon-list.video-icon {
    margin-top: 30px;
    line-height: 43px;
} 
.four-col li span {
    min-height: 40px;
    display: inline-block;
}    
.readmore-btn {
    border: 0;
    padding: 10px 25px;
    font-size: 14px;
    border-radius: 5px;
    font-weight: 600;
    background-color: #08c408 !important;
}
.four-col li span img {
    height: 46px;
    margin-top: 0 !important;
}   
ul.icon-list.video-icon img {
    width: 40px;
    margin-bottom: 0;
    display: inline-block;
    vertical-align: top;
    margin-top: 0;
    margin-right: 10px;
}   
ul.icon-list {
    float: left;
    width: 100%;
    text-align: center;
    padding: 0;
    list-style: none;
}
ul.icon-list li {
    display: inline-block;
    width: auto;
    padding: 0 8px;
}
ul.icon-list li img {
    width: 21px;
    margin-top: 30px;
    margin-bottom: 10px;
}    
ul.four-col li p {
    text-align: justify;
    padding: 0 5px;
    font-size: 12.9px;
    line-height: 19px;
    height: 220px;
    overflow: hidden;
    margin-bottom: 19px;
}
img.newimage1 {
    position: absolute;
    top: auto;
    right: 30px;
    width: 270px;
    z-index: 99;
}
.ui-slider-tab-content p span.author {
    margin: 5px 0;
}
.ui-slider-tab-content p {
    width: 65%;
    margin: auto;
    font-size: 20px;
    color: #9b9fa8;
    line-height: 23px;
    font-family: serif;
    font-style: italic;
}
.ui-slider-tabs-list li a img {
    width: 60px;
    height: 60px;
    object-fit: cover;
}   
.tagline {
    float: left;
    width: 100%;
    color: #08c408 !important;
    text-align: center;
    font-size: 29px;
    font-weight: 600;
    margin: 36px 0 30px 0;
}
img.storeimage {
    float: right;
    position: absolute;
    right: 30px;
    width: 270px!important;
    margin-top: 30px;
    z-index: 9;
} 
.socail-icon {
    display: inline-block;
    width: 100%;
    float: left;
    margin-bottom: 10px;
    text-align: center;
}
a.btn-ragister.back-trspt {
    width: auto;
    display: inline-block;
    margin: 0 7px;
    float: none;
    background: #fff;
    box-shadow: 0 0 3px #dbdbdb;
    padding: 6px 6px;
}     
.phone-store-back {
    float: left;
    width: 100%;
    background-color: #fcfcfc;
    margin-top: 37px;
    border-top: 1px #ccc solid;
}
.phone-app-store {
    float: left;
    width: 100%;
    padding: 50px 0 20px 0;
}
.phone-app-store ul {
    float: left;
    width: 100%;
}
.phone-app-store ul li {
    float: left;
    width: 33%;
    text-align: center;
}
.phone-app-store img {
    width: 75%;
    margin: 0 auto;
    text-align: center;
    margin-top: 20px;
}
.phone-app-store ul li p {
    background-color: #ffc202!important;
    padding: 30px 20px;
    min-height: 150px;
    font-size: 21px;
    line-height: 32px;
    color: #000000!important;
    border: 2px #ebc802 solid;
    border-radius: 6px;
    font-weight: 700;
}
.login-box .btn-ragister img {
    width: 22px;
    float: left;
}
a.btn-ragister.googleplus {
    margin-top: 0;
}
a.btn-ragister.instgram {
    margin-top: 0;
}    
.banner-home-mid {
    padding: 30px 0;
    width: 100%;
    float: left;
}    
div#mySliderTabs {
    overflow: hidden;
}
.bg-content div img {
    width: auto!important;
    height: auto!important;
    min-height: 30px!important;
    max-height: 260px;
    margin-top: 10px!important;
    border-radius: 9px;
    margin-left: -40px !important;
}
img.newimage {
position: absolute;
left: 30px;
width: 220px!important;
margin-top: 30px;
z-index: 9;
}
    
    
    #more {display: none;}
    #more1 {display: none;}
    #more2 {display: none;}
    #more3 {display: none;}

    @media screen and (max-width:1399px){
        ul.four-col li p {
    text-align: justify;
    padding: 0 5px;
    font-size: 12.9px;
    line-height: 19px;
    height: 270px;
    overflow: hidden;
    margin-bottom: 19px;
}
    }   
    
    @media screen and (max-width:1299px){
        ul.four-col li p {
    text-align: justify;
    padding: 0 5px;
    font-size: 12.9px;
    line-height: 19px;
    height:320px;
    overflow: hidden;
    margin-bottom: 19px;
}
    }     
    
@media screen and (max-width:991px){
        ul.four-col li p {
    text-align: justify;
    padding: 0 5px;
    font-size: 12.9px;
    line-height: 19px;
    height:250px;
    overflow: hidden;
    margin-bottom: 19px;
}
img.newimage1 {
    position: relative;
    top: auto;
    right: 0;
    width: 230px;
    z-index: 99;
}    
    .bg-content div img {
    width: auto!important;
    height: auto!important;
    min-height: 30px!important;
    max-height: 170px !important;
    margin-left: 0px !important;
}
div#mySliderTabs {
    text-align: center;
} 
img.newimage {
    position: relative;
    left: auto;
    width: 220px!important;
    margin-top: 30px;
    z-index: 9;
    right: auto;
    margin: 0 auto;
    margin-bottom: 20px;
}    
img.storeimage {
    position: relative;
    right: auto;
    width: 220px!important;
    margin-top: 30px;
    z-index: 9;
    right: auto;
    margin: 0 auto;
    margin-bottom: 20px;
}    
}   
    
@media screen and (max-width:767px){
        ul.four-col li p {
    text-align: justify;
    padding: 0 5px;
    font-size: 12.9px;
    line-height: 19px;
    height:auto;
    overflow: hidden;
    margin-bottom: 19px;
}    
ul.four-col li p {
    min-height: auto;
}    
div#PageHeader .right-head {
    padding: 185px 0 10px 18px;
    float: left;
}
ul.four-col li p {
    text-align: center;
    padding: 0 0;
    font-size: 12.9px;
    line-height: 19px;
}    
img.newimage1 {
    position: relative;
    top: auto;
    right: 0;
    width: 100%;
    z-index: 99;
}    
.tagline {
    float: left;
    width: 100%;
    color: #08c408 !important;
    text-align: center;
    font-size: 19px;
    font-weight: 600;
    margin: 15px 0 10px 0;
    line-height: normal;
    padding: 0 0px;
}    
.phone-app-store ul li {
    float: none;
    width: 90%;
    text-align: center;
    margin: 0 auto;
}
    
}  
.main-div{
	border: 1px solid #000000;
    height: 23px;
    text-align: center;
    background-color: #000000;
    color: #ffc202;
    font-size: 22px;
    font-weight: bold;
}  
    
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="inc/templates/<?=D_TEMP ?>/template.css">
<link rel="stylesheet" href="inc/templates/<?=D_TEMP ?>/testimonial/jquery.sliderTabs.min.css">
<link rel="stylesheet" href="inc/templates/<?=D_TEMP ?>/testimonial/jquery.sliderTabs.css">
<script src="inc/templates/<?=D_TEMP ?>/testimonial/jquery.sliderTabs.min.js"></script>
<script src="inc/templates/<?=D_TEMP ?>/testimonial/jquery.sliderTabs.js"></script>
<script>
    jQuery(document).ready(function(e) {
        jQuery("#mySliderTabs").sliderTabs({
        arrowWidth: 35,                 // Width of tab arrows in pixels
        classes: {                      // Custom classes to attach
            leftArrow: '',              //  - Left arrow
            panel: '',                  //  - All content panels
            panelActive: '',            //  - The selected content panel
            panelsContainer: '',        //  - Parent div containing all hidden and shown panels
            rightArrow: '',             //  - Right arrow
            tab: '',                    //  - All tabs (<li> elements)
            tabActive: '',              //  - The selected tab
            tabsList: '',
                            //  - The list of tabs (<ul> element)
        },
        defaultTab: 1,                  // Index of the default tab OR the jQuery object of the <li> element
        height: '',                     // Integer or '': Height in pixels of the whole widget. '' means fluid height
        position: "bottom",             // 'top' or 'bottom': Orientation of the tabs relative to the content
        tabHeight: "auto",                  // Height of the tabs bar and arrows in pixels
        tabSliders: true,               // Use sliding tabs. If false, overflow tabs are hidden
        tabSlideLength: 100,            // Length in pixels to slide tabs when an arrow is clicked
        tabSlideSpeed: 200,             // Time (in milliseconds) of the tab sliding animation
        transition: 'slide',            // 'slide' or 'fade': The transition to use when changing panels
        transitionSpeed: 200,           // Time (in milliseconds) of the transition animation
        width: ''                       // Width in pixels of the whole widget
        
    });
    });
    $(document).ready(function(){
        $(".login-btn").click(function(){
            $(".login-top").slideToggle();
            return false;
        });

    });
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}

function myFunction1() {
  var dots = document.getElementById("dots1");
  var moreText = document.getElementById("more1");
  var btnText = document.getElementById("myBtn1");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
function myFunction2() {
  var dots = document.getElementById("dots2");
  var moreText = document.getElementById("more2");
  var btnText = document.getElementById("myBtn2");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
function myFunction3() {
  var dots = document.getElementById("dots3");
  var moreText = document.getElementById("more3");
  var btnText = document.getElementById("myBtn3");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
<body id="splitpage" <?=$HEADER_ON_LOAD ?>>


<div id="MainPageBackground">
<div class="">
<div class="header-home">
<div class="page_header" id="PageHeader">
<?  $fdata = DisplayFeaturedMembers(12,4); $wdata = DisplayFeaturedMembers(20);     ?>

<style>

img.banner-home-img {
    width: 100%;
}    
.bg-content {
    float: left;
    width: 100%;
    text-align: center;
   
    height: auto;
    background-size: cover;
    margin-bottom: 25px;
    height: 500px;
}

div#PageHeader {
    width: 100% !important;
    margin: 0 auto;
    float: none;
}
a.btn-ragister {
margin-top: 105px;
}

a.btn-ragister {
margin-top: 37px;
}
div#PageHeader .right-head {
    padding: 42px 170px 20px 10px;
}
#PageHeader .right-head select {
    text-align: right;
    float: left;
    width: 150px;
    display: inline-block;
    height: 41px;
    padding: 0 10px;
}
a.login.login-btn {
    float: right;
    width: auto;
    padding: 12px 30px;
    background-color: #ffc202!important;
    border: 0;
    color: #000;
    border-radius: 4px!important;
    text-transform: uppercase;
    font-weight: 600;
}


.navbar.navbar-inverse.navbar-fixed-top {
    background: transparent;
    border: 0;
}
div#page_footer {
    box-shadow:none;
} 

.login-top {
   position: absolute;
   width: 100%;
   left: 0px;
   top: 85%;
}
.login-top ul.form.custom-border {
   border: 0;
}
.login-top ul.form.custom-border .CapBody {
   padding: 21px 20px;
}
.login-top ul.form.custom-border .CapBody .line-txt {
   margin-bottom: 30px;
}
.login-top ul.form.custom-border .CapBody input {
   border: 1px #ccc solid;
   box-shadow: 0 0 0 transparent;
   padding: 12px;
}
.login-top ul.form.custom-border .CapBody input.green-btn {
   font-size: 14px;
   text-transform: uppercase;
   font-weight: 500;
   margin-top: 0;
}
.sub_menu.hidden-xs.hidden-sm {
    display: none !important;
}
#PageHeader .sub_menu {
    width: 100%;
    min-height: 52px;
    background-color: #000!important;
    -moz-box-shadow: 0 3px 7px #c1c1c3;
    -webkit-box-shadow: 0 3px 7px #c1c1c3;
    -khtml-box-shadow: 0 3px 7px #c1c1c3;
    box-shadow: 0 3px 7px #c1c1c3;
    margin: 0 0 0 0;
    display: none !important;
}
.content-width{ width:70%;}
#MainPageBackground #page_container {width: auto;}
.navbar.navbar-inverse.navbar-fixed-top { background: none;}
.wide_wrapper { position: inherit;}
.navbar.navbar-inverse.navbar-fixed-top {position: absolute;background: none; z-index: 1;}
#splitpage #main_content_wrapper { background: #ffffff; border:0px;}
#splitpage #main_wrapper_bottom {   background: #ffffff;}
.Home_ImageBar { background: url('inc/templates/<?=D_TEMP ?>/images/index_imagebox.jpg'); border-bottom:2px solid #929091; height:180px; }
#style4 ul li { color:white; }
#style4 .previous_button {  background: url(inc/templates/<?=D_TEMP ?>/images/ho2.jpg) no-repeat; width:38px; height:137px;  }
#style4 .previous_button_over {  background: url(inc/templates/<?=D_TEMP ?>/images/ho2.jpg) no-repeat; width:38px; height:137px; }
#style4 .previous_button_disabled {  background: url(inc/templates/<?=D_TEMP ?>/images/ho2.jpg) no-repeat; width:38px; height:137px; }
#style4 .next_button {   background: url(inc/templates/<?=D_TEMP ?>/images/ho2b.jpg) no-repeat; width:38px; height:137px; }
#style4 .next_button_over {  background: url(inc/templates/<?=D_TEMP ?>/images/ho2b.jpg) no-repeat; width:38px; height:137px; }
#style4 .next_button_disabled {  background: url(inc/templates/<?=D_TEMP ?>/images/ho2b.jpg) no-repeat; width:38px; height:137px; }
.steps { font-size:16px; color:#DA0303;}
.pImage { float:left; width:100px; height:150px; margin-right:32px;}
.pImageBorder { border:3px solid #eee;}
.pImageUsername { font-size:11px; font-weight:bold; text-align:center}
#MenuBar, .sub_menu{display:none;}
.footer-banner-add{display:none;}
#page_container{width:auto;}
.flags_table{display:none;}
.header-home{position:absolute; float: left; width: 100%;}
.right-head {
    float: right;
    text-align: right;
    width: auto;
    margin: 33px 20px 0px 0px;
}
.four-col{
    margin-bottom:0;
}
table.member-info-table td {
    padding: 1% 0;
}
@media (max-width:1030px){

div#PageHeader{ width: 90%;}    
.content-width {
    width: 85%;
}
}


@media screen and (max-width:767px){
   .banner-home-mid .btn-row a.green-btn {
   right: 20px;
}
div#PageHeader .right-head {
    padding: 215px 0 10px 18px;
    float: left;
}
.bg-content div img {
    width: auto!important;
    height: auto!important;
    min-height: 30px!important;
    max-height: 120px!important;
    margin-left: 0!important;
}    
#PageHeader .right-head select {
   text-align: right;
   float: left;
   width: 129px;
   display: inline-block;
   height: 41px;
   padding: 0 10px;
}
}

@media (max-width:680px){
div#PageHeader{ width: 100%;}
.content-width { width: 95%;}
}
@media (max-width:550px){
div#PageHeader,.content-width { width: 100%;}
}
</style>
            <div class="right-head" style=" <?php if($page == "index"){?> margin:0px 20px 0px 0px; <?php } ?>">
            <!--4-->
                <?php

                if(isset($_SESSION['lang'])){
                    $lang = $_SESSION['lang'];
                    $$lang = "selected = 'selected'";
                }
                else{
                    $english = "selected = 'selected'";
                }

                
                ?>
                <form class="f_left">
                    <select class="language f_left padding_5" name="lang" id="lang" onchange="location = this.options[this.selectedIndex].value;"> 
                        <option value="/index.php?l=english" <?php if(isset($english)){ echo $english;}?>>English</option>
                        <option value="/index.php?l=bosnian" <?php if(isset($bosnian)){ echo $bosnian;}?>>Bosnian</option>
                        <option value="/index.php?l=turkey" <?php if(isset($turkey)){ echo $turkey;}?>>Turkey</option>
                        <option value="/index.php?l=spanish" <?php if(isset($spanish)){ echo $spanish;}?>>Spanish</option>
                        <option value="/index.php?l=russian" <?php if(isset($russian)){ echo $russian;}?>>Russian</option>
                        <option value="/index.php?l=czech" <?php if(isset($czech)){ echo $czech;}?>>Czech</option>
                        <option value="/index.php?l=japanese" <?php if(isset($japanese)){ echo $japanese;}?>>Japanese</option>
                        <option value="/index.php?l=slovenian" <?php if(isset($slovenian)){ echo $slovenian;}?>>Slovenian</option>
                        <option value="/index.php?l=swedish" <?php if(isset($swedish)){ echo $swedish;}?>>Swedish</option>
                        <option value="/index.php?l=slovak" <?php if(isset($slovak)){ echo $slovak;}?>>Slovak</option>
                        <option value="/index.php?l=thai" <?php if(isset($thai)){ echo $thai;}?>>Thai</option>
                        <option value="/index.php?l=danish" <?php if(isset($danish)){ echo $danish;}?>>Danish</option>
                        <option value="/index.php?l=chinese" <?php if(isset($chinese)){ echo $chinese;}?>>Chinese</option>
                        <option value="/index.php?l=romanian" <?php if(isset($romanian)){ echo $romanian;}?>>Romanian</option>
                        <option value="/index.php?l=german" <?php if(isset($german)){ echo $german;}?>>German</option>
                        <option value="/index.php?l=italian" <?php if(isset($italian)){ echo $italian;}?>>Italian</option>
                        <option value="/index.php?l=vietnamese" <?php if(isset($vietnamese)){ echo $vietnamese;}?>>Vietnamese</option>
                        <option value="/index.php?l=arabic" <?php if(isset($arabic)){ echo $arabic;}?>>Arabic</option>
                        <option value="/index.php?l=portugues" <?php if(isset($portugues)){ echo $portugues;}?>>Portugues</option>
                        <option value="/index.php?l=norwegian" <?php if(isset($norwegian)){ echo $norwegian;}?>>Norwegian</option>
                        <option value="/index.php?l=dutch" <?php if(isset($dutch)){ echo $dutch;}?>>Dutch</option>
                        <option value="/index.php?l=korean" <?php if(isset($korean)){ echo $korean;}?>>Korean</option>
                        <option value="/index.php?l=croatian" <?php if(isset($croatian)){ echo $croatian;}?>>Croatian</option>
                        <option value="/index.php?l=taiwanese" <?php if(isset($taiwanese)){ echo $taiwanese;}?>>Taiwanese</option>
                        <option value="/index.php?l=polish" <?php if(isset($polish)){ echo $polish;}?>>Polish</option>
                        <option value="/index.php?l=french" <?php if(isset($french)){ echo $french;}?>>French</option>
                        <option value="/index.php?l=greek" <?php if(isset($greek)){ echo $greek;}?>>Greek</option>
                    </select>
                    <? if($page == "index"){ ?>
                        <a class="login login-btn" href="">Login Here</a>
                    <? } ?>
                </form>
                
                <div style="display:none;" class="login-top">
                <div class="content-width">
                <div class="login-box">
                    <form method="post" action="<?=DB_DOMAIN ?>index.php" name="LoginForm" onSubmit="return CheckNullsLogin('<?=$GLOBALS['_LANG_ERROR']['_incomplete'] ?>');">
                    <input name="do" type="hidden" value="login" class="hidden">
                    <input name="visible" value="0" type="hidden">
                    <input name="do_page" type="hidden" value="login" class="hidden">
                
                    <ul class="form custom-border">   
                 
                    <div class="CapBody">   
                
                <? if (defined('FACEBOOK_APP_ID')  && FACEBOOK_APP_ID !="") { ?>             
                <li>
                 <a class="btn-ragister" href="<?=DB_DOMAIN ?>index.php?dll=fblogin"><img src="/inc/templates/<?=D_TEMP ?>/images/facebook-f.jpg" />Login Fast with facebook</a><br />
                </li>
                <? } ?>
                 <div class="socail-icon">
                 <a class="btn-ragister back-trspt" style="margin-top: 0px !important;" href="<?=DB_DOMAIN ?>index.php?dll=fblogin"><img src="/inc/templates/<?=D_TEMP ?>/images/facebok.png" /></a>
                <a class="btn-ragister back-trspt" style="margin-top: 0px !important;" href="<?=DB_DOMAIN ?>index.php?dll=fblogin"><img src="/inc/templates/<?=D_TEMP ?>/images/twitter.png" /></a>
                 <a class="btn-ragister back-trspt" class="google" href="<?=DB_DOMAIN ?>index.php?dll=fblogin"><img src="/inc/templates/<?=D_TEMP ?>/images/instagram.png" /></a>
                 <a class="btn-ragister back-trspt" class="insta" href="<?=DB_DOMAIN ?>index.php?dll=fblogin"><img src="/inc/templates/<?=D_TEMP ?>/images/google-plus.png" /></a>
                </div>
                <li><div class="line-txt"><span>or sign in below</span></div></li>    
                        <li><input placeholder="<?=$GLOBALS['_LANG']['_username'] ?>" tabindex="1" maxlength="15" name="username" id="e_username" type="text" class="input" size="25" <? if(isset($_COOKIE['emeeting']['username'])){ print "value='".$_COOKIE['emeeting']['username']."'"; } ?>>
                        </li>
                        <li><input placeholder="<?=$GLOBALS['_LANG']['_password'] ?>" tabindex="2" maxlength="25" name="password" id="e_password" type="password" class="input" size="25"></li>
                        <? if(D_REGISTER_IMAGE ==1){ ?>
                
                        <? } ?>
                        <li><input class="green-btn" maxlength="15" type="submit"  value="<?=$GLOBALS['_LANG']['_login'] ?>" class="MainBtn"></li>
                        <!--<li><input type="checkbox" name="remember" value="1" style="margin-right:15px;" checked='checked'><?=$GLOBALS['_LANG']['_rememberMe']  ?></li>-->
                        <li class="forget-txt"><a href="#" onclick="toggleLayer('ForgottenPassword2'); return false;"><?=$GLOBALS['LANG_COMMON'][1] ?></a></li>
                    <?php /*?>  <? if(VALIDATE_EMAIL==1){ ?>
                        <li><img src="<?=DB_DOMAIN ?>images/DEFAULT/_acc/emoticon_smile.png" align="absmiddle"> <a href="#" onclick="toggleLayer('ActAccount'); return false;"><?=$GLOBALS['LANG_LOGIN']['a7'] ?></a></li>
                        <? } ?><?php */?>
                        </div>
                    </ul>
                    </form> 
                    <div style="display:none" id="ForgottenPassword2">  
                        <form method="post" action="<?=DB_DOMAIN ?>index.php" name="ForgotPassword">
                        <input name="do" type="hidden" value="password" class="hidden">
                        <input name="do_page" type="hidden" value="login" class="hidden">
                        <input name="username" type="hidden" value="" class="hidden">
                        <ul class="form forget-form">   
                        <div class="CapBody"><li>Enter your registration email<br /> and we'll send your a password</li>
                            <li><input maxlength="150" name="email" type="text" size="20" class="input"></li>
                            <?php /*?><? if(D_REGISTER_IMAGE ==1){ ?><li><label ><?=$GLOBALS['_LANG']['_verification'] ?>:</label> <input maxlength="15" type="text" name="code" id="C4" class="input"><br><img name="Verification Image" src="<?=DB_DOMAIN ?>inc/classes/class_regimg_img.php?regen=y&<? echo time(); ?>"></li><? } ?><?php */?>
                            <li><input class="green-btn" type="submit"  value="<?=$GLOBALS['_LANG']['_submit'] ?>" class="MainBtn"></li>
                        </div>
                        </ul>
                        </form>
                    </div>
                </div>
                </div>
                </div>
                <!--4-->
            </div>  
                
</div>
</div>
<div class="bg-content">
 <div class="">  <img src="../inc/templates/<?=D_TEMP ?>/images/1596063901259.JPEG" class="newimage" style="width: auto;
    float: left;
    margin-top: 1%;
    margin-left: 2%;
    height: -webkit-fill-available !important;
}" /></div> 
 <div class="content-width"> 
 <div class="box-member-search" style="display: none;">
 <form method="post" name="MemberSearch" action="index.php?dll=search&view_page=1">               
<input name="do" type="hidden" value="add" class="hidden">            
<input name="do_page" type="hidden" value="search" class="hidden">
<input type="hidden" name="page" value="1" class="hidden">
<input type="hidden" name="Extra[zero]" value="1" class="hidden">
<input name='TotalNumberOfRows' type='hidden' value='3' class='hidden'>               
<input type='hidden' name='SeN[1]' value='country' class='hidden'>
<input type='hidden' name='SeT[1]' value='3' class='hidden'>
<input type='hidden' name='SeN[2]' value='gender' class='hidden'>
<input type='hidden' name='SeT[2]' value='3' class='hidden'>
<input type='hidden' name='SeN[3]' value='em_85820081128' class='hidden'>
<input type='hidden' name='SeT[3]' value='3' class='hidden'>
<?php /*?><h2 class="heading"><?=$LANG_BODY['_member']. " ".$LANG_BODY['_search'] ?></h2><?php */?>

<div class="logo-top-search" style="display: none;"><img class="heart" src="../inc/templates/<?=D_TEMP ?>/images/heart-icon.jpg" /> <img src="../inc/templates/<?=D_TEMP ?>/images/logo.jpg" /></div>
<table class="member-info-table" width="300"  border="0" cellpadding="0" cellspacing="0" style="display: none;" >
<tr> <td width="122" height="30"><?=$LANG_BODY['_home1'] ?> </td><td colspan="2">
<select name="select"><?=displayGenders() ?></select>
</td></tr><tr><td height="30"><?=$LANG_BODY['_home2'] ?> </td><td colspan="2">
<select name="SeV[2]"><?=displayGenders(1) ?></select>
</td></tr>

<tr>
<td  width="30"><?=$LANG_BODY['_age'] ?></font></td>
<td  colspan="2"><? print DoAge(1); ?></td>
</tr>
<tr>
  <td height="30"><?=$LANG_BODY['_withPics'] ?></td><td width="140"><input type="checkbox" name="Extra[pics]" value="1"> &nbsp;&nbsp;&nbsp;&nbsp; <?=$lang_global_options['13'] ?> </td>
  <td width="65"><input type="checkbox" name="Extra[online]" value="1"></td>
</tr>
<tr>
<td height="30" colspan="3" valign="bottom">
<input type="submit" name="submit" value="&nbsp;&nbsp;<?=$LANG_BODY['_search'] ?>&nbsp;&nbsp;" class="NormBtn" ><br />
<a class="btn-ragister" href="/index.php?dll=fblogin"><img src="../inc/templates/<?=D_TEMP ?>/images/facebook-f.jpg" />Register with facebook</a>
</td>
</tr>
</table>
</form>
</div>
</div>


</div>
 <div class="content-width"> 
 <ul class="four-col">
 <li><span><img src="../inc/templates/<?=D_TEMP ?>/images/new_images/i1.png" /></span>
 <h1>Protection</h1> 
 <p>For your protection, we have engaged the leader in ecommerce protection and personal data collection services, through the use of Geo Trust True Business ID with 256-bit EV SSL certificate, your personal details are protected by the industry highest and most comprehensive security and trust encryption features to protect you and all <span id="dots3">...</span><span id="more3"> of your personal details.</p><button class="readmore-btn" onclick="myFunction3()" style="background-color: #00b900; color: white;" id="myBtn3">Read more</button>
</li>
  <li><span><img src="../inc/templates/<?=D_TEMP ?>/images/new_images/i2.png" /></span>
 <h1>Verification</h1> 
<p>Conducted by Optimum Screening a global company providing the most comprehensive and secure background checks needed to verify someone's identification to see if they have any criminal convictions, past aliases, fugitive warrants and much more. Which means all of our members are completely vetted to make sure that they are <span id="dots">...</span><span id="more"> real people and not bots pretending to be people or worse to make sure that the picture you are talking to is not being answered by some guy named Boris!</p><button class="readmore-btn" onclick="myFunction()" style="background-color: #00b900; color: white;" id="myBtn">Read more</button>
</li>
   <li><span><img src="../inc/templates/<?=D_TEMP ?>/images/new_images/i3.png" /></span>
 <h1>Attention</h1> 
<p> Our community is made up of real people who are sincerely seeking that elusive soul mate. We pride ourselves on who we allow to become members of our community by finding new ways to ensure the safety and protection of our members, and as such we will do everything in our power to keep out all undesirables’ and deviants from entering our site,<span id="dots1">...</span><span id="more1"> all the while facilitating as much attention as is needed to find that perfect person for them to share their lives with.</p><button class="readmore-btn" onclick="myFunction1()" style="background-color: #00b900; color: white;" id="myBtn1">Read more</button>
</li>
    <li><span><img src="../inc/templates/<?=D_TEMP ?>/images/new_images/i4.png" /></span>
 <h1>Communication</h1> 
 <p>At MyNewBride, we emphasize transparency coupled with exceptional services. Which is why we have upped our level of commitment by providing our members with Free On Demand video chat, email services, video and picture uploads, and many more... We have also provided the added options to our members where they can reach out to that <span id="dots2">...</span><span id="more2"> special someone with gifts and floral delivery service at their leisure.</p><button class="readmore-btn" onclick="myFunction2()" style="background-color: #00b900; color: white;" id="myBtn2">Read more</button>
</li>
 
 </ul>
 </div>
 
 <style>
	.modalDialog {
    position: fixed;
    font-family: Arial, Helvetica, sans-serif;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.8);
    z-index: 99999;
    opacity:0;
    -webkit-transition: opacity 400ms ease-in;
    -moz-transition: opacity 400ms ease-in;
    transition: opacity 400ms ease-in;
    pointer-events: none;
}
.modalDialog:target {
    opacity:1;
    pointer-events: auto;
}
.modalDialog > div {
    width: 800px;
    position: relative;
    margin: 10% auto;
    padding: 5px 20px 13px 20px;
    border-radius: 10px;
    background: #fff;
    background: -moz-linear-gradient(#fff, #999);
    background: -webkit-linear-gradient(#fff, #999);
    background: -o-linear-gradient(#fff, #999);
}
.close {
    background: #606061;
    color: #FFFFFF;
    line-height: 25px;
    position: absolute;
    right: -12px;
    text-align: center;
    top: -10px;
    width: 24px;
    text-decoration: none;
    font-weight: bold;
    -webkit-border-radius: 12px;
    -moz-border-radius: 12px;
    border-radius: 12px;
    -moz-box-shadow: 1px 1px 3px #000;
    -webkit-box-shadow: 1px 1px 3px #000;
    box-shadow: 1px 1px 3px #000;
}
.close:hover {
    background: #00d9ff;
}
 </style>
 
 <div id="openModal" class="modalDialog">
    <div><a href="#close" title="Close" class="close">X</a>
	
		<style type="text/css">
  /*  div#openModal {
    background-color: transparent;
}        */
    div#openModal.modalDialog>div {
    border-radius: 0;
}        
    .close:hover {
    background: #08c408!important;
}        
    div#openModal {
    position: fixed;
    height: auto;
    overflow: auto;
}
    div#openModal.modalDialog>div {
    width: 800px;
    position: relative;
    margin: 10% auto;
    padding: 5px 20px 13px 20px;
    border-radius: 10px;
    background: #fff;
    background: -moz-linear-gradient(#fff,#999);
    background: none;
    background: -o-linear-gradient(#fff,#999);
    background-color: #fff;
}        
        .text-center {
    text-align: center;
}    
.matcmaking-mambership h5 {
    width: 100%;
    display: inline-block;
    font-size: 18px;
    color: #000;
    font-weight: 700;
    margin-bottom: 20px;
    margin-top: 0;
    line-height: 21px;
}
.matcmaking-mambership h2 {
    color: #ffcc66;
    background-color: #000;
    width: auto;
    display: inline-block;
    padding: 10px 50px;
    font-weight: 600;
    font-size: 19px;
    margin-bottom: 40px;
}
.matcmaking-mambership p {
    color: #000;
    font-size: 16px;
    margin-bottom: 15px;
    margin-top: 0;
    line-height: 21px;
}
.matcmaking-mambership h1 {
    color: #000;
    font-weight: bold;
    margin-top: 30px;
    margin-bottom: 16px;
}

.matcmaking-mambership ul {
    margin: 0 0 30px 0;
    padding: 0;
}
.matcmaking-mambership ul li {
    width: 100%;
    float: left;
    margin-bottom: 14px;
    font-size: 16px;
    line-height: 21px;
}
img.flot-ldt {
    float: right;
    width: 100px;
}
img.flot-riht {
    float: left;
    width: 100px;
}
button.sumbmit-qustion.btn {
    background-color: #08c408 !important;
    color: #fff;
    padding: 11px 60px;
    font-size: 15px;
    margin-top: 20px;
    margin-bottom: 20px;
}
matcmaking-mambership p {
    font-size: 16px;
}
.qution-makig-inner ul {
    list-style: none;
    padding: 0;
    margin: 0;
}
.qution-makig-inner ul li {
    width: 100%;
    float: left;
    margin-bottom: 15px;
    font-size: 16px;
    font-weight: 600;
}
.qution-makig-inner {
    margin-top: 20px;
    width: 100%;
    float: left;
}
.qution-makig-inner ul li input {
    width: 100%;
    margin-top: 4px;
    font-weight: normal;
    font-size: 14px;
    padding: 10px 11px;
    border: 1px #ccc solid;
}
div#openModal.modalDialog>div {
    border-radius: 0 !important;
    margin-top: 60px !important;
}           
</style>
<div class="matcmaking-mambership">
<div class="container">
<div class="row">
<div class="col-md-12">
<h5 style="text-align: center;margin-top: 20px;">Membership Expectations and Rules</h5>

<div class="text-center">
<h2 style="text-align: center;">OUR MEMBERS EXPECTATION POLICY</h2>
</div>

<p>We promise the services offered by MyNewBride will ensure to all of our members a safe and secure environment. We are an international marriage network that does not sanction hookups, censored images, or criminal elements to include domestic or sexual abusers and unverified users. We present for your security a state of the art authentication and verification systems that are good for the real people who want an environment free from the aforementioned radical elements,but bad for the unwanted individuals which are prevalent on almost all other platforms.</p>

<h5>To comply with this, we expect the following from our members:</h5>

<p>Every male member using MyNewBride must treat each female they come into conversation with as their potential soul mate. At any given moment you speak, write, or message a female, you will respectfully choose your words and behavior.Think about how you would like another man treating your mother or your sister;with the utmost respect when you approach another lady.</p>

<p>At MyNewBride,we do not sanction any of our members a platform to fulfill their sexual fantasies or a place for them to submit explicit images, display lousy behavior, and or be disrespectful to other members. You will be terminated forthwith from our platform. Similarly, if the female you&rsquo;re speaking to gets the intention you want to be with her just for a hookup, we will bar you from our service. On a similar note, as we are an International Marriage Network,acting with in the guidelines of IMBRA policies (see policy below) and we discover a user&rsquo;s intentions are only for obtaining a visa, they will be removed from our platform.</p>

<p>We do not condone females being coerced to leaving the platform in a brief period.Ladies, be conscious of this fact, you will never meet your soul mate in a matter of a few months. Any man who is seriously interested in you should have the decency to spend a reasonable period to get to know as much information about you while, according to you, the same courtesy for you to get to know them.Your search for a soul mate is not a race; this is an investment in yourself to find the right person to share the rest of your life with you. Here is where you are trying to make the best decision to find a life partner. While on our platform, we here at MyNew Bride will endeavor to give you the best meeting place for members to find their perfect &ldquo;one.&rdquo;MyNewBride serves as a &ldquo;safe&rdquo;haven while offering to provide you with the best service to ensure your protection.</p>

<p>If a male or female does not have your best interest at heart and is undecided about marriage or if anything goes wrong during a meeting, we will assist you in findinga new life partner.We will make this our commitment to all of our members!</p>

<h5 style="text-center;">Membership Expectations and Rules</h5>

<p>Finally, We discourage all members from engaging with more than three to four females or males at a time. Folks, there can only be one! And again, we want to re-empathize that this service is not for hookups or speed dates; you&rsquo;re here to meet your soul mate. It is not humanly possible to engage with more members simultaneously, and believe that you can pick one at the last minute. Take a few months to interact with the persons you like. With in that period, you should both be able to decide if you would like to take the time to be one on one and seriously give it a real chance of developing into the kind of love you are seeking with that particular one person.</p>

<p>Finding your other half is about persuing personal connection and personal choice. Deep relationships cannot be formed based on engaging with many members. In today&rsquo;s world, it takes the average person around six months or more to meet their other half before committing seriously.We urge all members to focus on their decisions, refine them, and allocate a significant amount of time to getting to know one person only. You can only commit to one bride or groom.</p>

<h1>Rules</h1>

<h5>To be a member and remain a member of MyNewBride LLC, you will need to adhere to the following rules:</h5>

<ul><li>1. Upon registration, all potential members will be subject to an extensive criminal record check. </li>
	<li>2. Those who sign up to MyNewBride who have criminal, sexual, or domestic convictions (see our related policy links at the bottom of each page) will not be allowed to use our platform.</li> 
    <li>3. It would be best if you abode by our no scamming and spamming policy (found inside). Otherwise, you will be blocked from our service.</li> 
    <li>4. All members will supply the following identification documents: current passport, driving license, or a country identification card and an existing selfie. All documents provided will be verified and matched with your selfie in less than 3 minutes if the form is a forgery or a photoshop piece. If any questions arise, you may be asked to present proof of residence in the way of a bill or mail addressed to your home as listed.</li> 
    <li>5. Males are subject to a nominal monthly membership fee.</li> 
    <li>6. Females will not need to pay a membership fee.</li> 
    <li>7. If we sense you&rsquo;re using this service for speed dates or short term hookups, we will remove you.</li> <li>8. If you experience any rude behavior from the person you&rsquo;re engaging with, report it to us immediately. Similarly, if you&rsquo;re the person promoting this behavior, you will be banned.</li> 
    <li>9. We see no reason to be rude folks;there are 7.8 billion people globally;we will invite all those who are single to join us. Please help us; all it takes is one friend to tell a friend, and so on and so on. We will find you,your soul mate!</li> 
    <li>10. To be eligible for our ongoing support to your marriage day, you must remain a user of our service in good standing without breaking the rules outlined here in.</li> 
    <li>11. Ladies and gentlemen, by you being here and undergoing our process, we assume that you are a potential member very serious about finding your special someone for life. Yes, we have gone to the extreme to assure that you will meet the very best caliber of men and women while searching for your soul mate. Good Luck!</li>
</ul>

<h5>For more information regarding our rules, please visit our policies section at the bottom of each page.</h5>

<p>MyNewBride, LLC <br />
    Management</p>
</div>
</div>
</div>
</div>

    </div>
</div>
 
 <!-- open a modal -->

  
  <!--modal end-->
  <script>
	$('.policy_modal').click(function(){		
		$('.modalDialog').css('opacity', 1);
	});	
  </script>
 
 
 
<div class="phone-store-back">
 <div class="content-width">
     <div class="phone-app-store">
    <a style="cursor:pointer;text-decoration: none;" class="tagline policy_modal" href="#openModal">
	<div class="text-center">     
	 OUR MEMBERS EXPECTATIONS POLICY
         </div>
	</a>		
     <ul>
     <li><img src="../inc/templates/<?=D_TEMP ?>/images/preview4.jfif"></li>
    <li><p style="color: #444444">MyNewBride is On All Your Devices <br> Now That You've Found Her Take Her With You Always</p></li> 
    <li><img src="../inc/templates/<?=D_TEMP ?>/images/preview1.jfif"></li>     
     </ul>
     </div>  
    </div> 
 </div>
 <div class="tagline">Join Us Today, You Too Can Find Your Soul Mate</div>
<div class="banner-home-mid">
<div class="btn-row">
<img src="../inc/templates/v18_premium/images/home-banner.jpg" alt="" class="banner-home-img">    
<a class="btn-ragister" href="/index.php?dll=fblogin"><img src="../inc/templates/<?=D_TEMP ?>/images/facebook-f.jpg" />Register with facebook</a>
<a class="green-btn" href="index.php?dll=register">FIND YOUR BRIDE</a>
</div>
</div>
 <div style="clear:both;"></div> 
<!-- <div style="clear:both;"> <img src="../inc/templates/<?=D_TEMP ?>/images/image.jfif" style="width: 300px;"></div> -->
<div id="mySliderTabs">
        <img src="../inc/templates/<?=D_TEMP ?>/images/image.jfif" class="newimage" style="width: 300px;">
        <ul>
          <li><a href="#testimonial-1"><img src="../inc/templates/<?=D_TEMP ?>/images/testimonial-1.jpg" /></a></li>
          <li><a href="#testimonial-2"><img src="../inc/templates/<?=D_TEMP ?>/testimonial/images/testimonial.png" /></a></li>
          <li><a href="#testimonial-3"><img src="../inc/templates/<?=D_TEMP ?>/images/testimonial-3.jpg" /></a></li>
        </ul>
        <div id="testimonial-1">
          <p>“Being single for many years and adroitly weaving my way through these many dating sites, I finally gave up, because they were only concerned with collecting my money than actually providing any kind of real service to really meet a good woman. I am completely delighted and very happy to have found this website with real people, transparency and not having to pay a credit for everything under the sun. Now I can reach out and talk to a lady who has the same values, needs and desires as I do, without having to put up with the fake bots spewing
          out gibberish at you a mile a minute. I highly recommend this marriage site to anyone who is serious about finding a real lady to start a new life with”.
           <span class="author"> William, Sacramento CA.</span> </p>
         
        </div>
        <div id="testimonial-2">
          <p>"We met on MyNewBride, and at first, Irina who is from Poltava, Ukraine, kept saying we were too different. But I could not give up on her from the first time that I saw her. After seven months of continuous communication, where we were able to see each other every day without having to pay crazy money for this privilege. We finally decided to meet in my city in Vienna Austria, where we spent three glorious weeks and where I asked her to be my wife. This site was a great gift for us. They were very instrumental in even helping me arrange for our meeting which was truly a great experience. I will highly recommend to all my friend about MyNewBride as this is where I have met the love of my life. From both of us, thank you MyNewBride.
" <span class="author"> Irina & Greg   Vienna, Austria</span></p>
        </div>
        <div id="testimonial-3">
           <p>"All I can say is wow! As a single successful business woman I have been looking around for a long time trying to find the right man for me. None of the places I have visited before had met my expectations and I had been on the top three dating website,
all of which I found to be substandard in comparison to the services, and transparency and I must also say a better selection when it comes to the caliber of men that you find on this site. I started out talking to three gentleman and with in a month I had decided to focus on one man. Now after  five months of positive visual conversation with Jan from Prague I believe I may have already found my soulmate.  I am finally feeling comfortable being on a website trying to find my love. I have not once ran into any of the despicable creatures that I have encountered elsewhere. Now I'm planning a trip to London and we will meet there. I'm so very happy finding this website and I will be forever grateful for being in this position where I can be a new bride in the short future." <span class="author"> Rachel, Aspen, CO.</span></p>
        </div>
<!--  <img src="../inc/templates/<?=D_TEMP ?>/images/preview6.png" class="storeimage" style="width: 300px;"> -->
      <img src="../inc/templates/<?=D_TEMP ?>/images/1596063901259.JPEG" class="newimage1" />
    </div>
    
    <div id="page_footer">
            <div class="content-width">
                <div class="footer_menu"> 
                    <ul class="icon-list video-icon">
                    <!-- <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/imgpsh_fullsize_anim (4).png"></a></li>
                  -->    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/imgpsh_fullsize_anim (3).png"> FREE ON DEMAND VIDEO TALK</a></li>
                     </ul>
                    <ul class="icon-list">
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/036-facebook.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/008-twitter.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/029-instagram.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/021-pinterest.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/018-reddit.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/009-tumblr.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/033-google-plus.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/social.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/027-linkedin.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/Mix.png"></a></li> 
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/odonklassniki.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/Vkontake.png"></a></li>    
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/035-flickr.png"></a></li>
                    <li><a href="#"><img src="../inc/templates/<?=D_TEMP ?>/images/001-youtube.png"></a></li>
                    </ul>
                    <ul class="footer_tabs">
                        <?=$FOOTER_MENU_BAR ?>                          
                    </ul>
                </div>  
            </div>
    
            <?=$FOOTER_MENU_TIMER ?>
            
            <?php e_footer() ?>
    
        </div>

    </div>
    
 </body>
 </html>
<?php /*?><table width="940"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="551" rowspan="2" valign="top"><div class="inner_nav_body" style="margin-top:25px; height:555px; border:0px;">

<h1 style="font-size:37px;font-weight:normal;"><?=TMP_TXT_1 ?></h1><p><?=TMP_TXT_2 ?></p> 

<div style="margin-left:10px; margin-top:20px;">
 
    <? foreach( $fdata as $value){ ?>
    <div class="pImage"><a href="<?=$value['link']; ?>"><img src="<?=$value['image']; ?>" border="0" width="96" height="96" class="pImageBorder"></a><div class="pImageUsername"><?=$value['username']; ?></div></div>
    <? } ?>

</div>

<div class="clear"></div>
<h2 style="margin-left:30px;"><?=$GLOBALS['_LANG']['_featured']." ".$GLOBALS['_LANG']['_members'] ?></h2><br>

</div></td>
    </tr>

<?
$result2 = $DB->Row("SELECT fvCaption FROM field_list_value WHERE fvid = '". $data['state'] ."' AND lang='".D_LANG."' Order by fvOrder");
if(!isset($result2)){ 
    $mystate ="none"; 
}else {
    $mystate = $result2['fvCaption'];
}
$mystate ="State/Province"; 
$data['state']="Region"; 
?>


<tr>
  <td height="30"><?=$LANG_BODY['_province'] ?></td><td colspan="2">
<? print '<div id="Link54" valign="top"><SELECT name="SeV[3]"  style="width:130px" id=country>'; ?>
</td></tr>



<tr>
  <td height="30"><?=$LANG_BODY['_withPics'] ?></td><td width="140"><input type="checkbox" name="Extra[pics]" value="1"> &nbsp;&nbsp;&nbsp;&nbsp; <?=$lang_global_options['13'] ?> </td>
  <td width="65"><input type="checkbox" name="Extra[online]" value="1"></td>
</tr>
<tr>
  <td height="30">&nbsp;</td>
  <td height="30" colspan="2" valign="bottom">
<input type="submit" name="submit" value="&nbsp;&nbsp;<?=$LANG_BODY['_search'] ?>&nbsp;&nbsp;" class="NormBtn"  style="font-size:16px;">
</td>
</tr>
</table>
</td>
  </tr>
  <tr>
    <td class="inner_nav_body" style="border:0px;padding:20px;">


<span style="font-size:21px;color:#666666; height:45px; margin-top:25px;"><?=$LANG_WELCOME['3'] ?></span>

<ul style="line-height:30px;margin-top:20px;color:#CF0079;">
<a href="index.php?dll=login"><img src="inc/templates/<?=D_TEMP ?>/images/home_join.png" border="0" style="float:right;"></a>
<li class="steps"><?=$LANG_WELCOME['4'] ?></li>
<li class="steps"><?=$LANG_WELCOME['5'] ?></li>
<li class="steps"><?=$LANG_WELCOME['6'] ?></li>
</ul>
<ul style="line-height:30px;margin-top:20px;color:#CF0079;">
<a href="index.php?dll=login"><img src="inc/templates/<?=D_TEMP ?>/images/home_join.png" border="0" style="float:right;"></a>
<li class="steps"><?=$LANG_WELCOME['4'] ?></li>
<li class="steps"><?=$LANG_WELCOME['5'] ?></li>
<li class="steps"><?=$LANG_WELCOME['6'] ?></li>
</ul><br>
<p><?=$LANG_WELCOME['7'] ?></p>

</td>
  </tr>
</table>
<table width="940" border="0" class="Home_ImageBar"><tr valign="top"><td width="546">


<div id="style4" style="margin-left:30px;margin-top:20px;">
<div class="previous_button"></div><div class="container">
<ul> 
<?  foreach( $wdata as $value){ ?>
<li><a href="<?=$value['link'] ?>"><img src="<?=$value['image'] ?>" width="96" height="96" border="0" style="cursor:pointer;"></a><br>
<strong><?=$value['username'] ?></strong></li><? } ?>
<?  foreach( $fdata as $value){ ?>
<li><a href="<?=$value['link'] ?>"><img src="<?=$value['image'] ?>" width="96" height="96" border="0" style="cursor:pointer;"></a><br>
<strong><?=$value['username'] ?></strong></a></li><? } ?>

</ul>

</div>
<div class="next_button"></div></div><script>function runTest() {  hCarousel = new UI.Carousel("style4");     }  Event.observe(window, "load", runTest); </script>

</td><td width="384" style="padding:15px;">

<span style="font-size:21px;color:#ffffff; height:45px; margin-top:25px;"><?=TMP_TXT_3 ?></span>
<p style="color:white;"><?=TMP_TXT_4 ?></p>
<p><a href="index.php?dll=login" style="color:white;"><?=$LANG_WELCOME['_join2'] ?></a></p>

</td></tr></table>


 <?php */?>

<style>
    .slider-form .search_bar{
    display:none;
    }
    .search_bar{
    display:none;
    }
    .what-happening-world{
    display:none;
    }
    .what-happening-world whatsh-gap{
    display:none;
    }
    .send-here-flower{
    display: none;
    }
</style>

 <div id="main">
<div id="main_content_wrapper"  style="display: block !important;">


    <? if(!isset($HEADER_SINGLE_COLUMN)){ ?><div class='conten_outer' style="padding:10px 20px;"> <? } ?>

        <div class="clear"></div>

        <? if(isset($ERROR_MESSAGE) && strlen($ERROR_MESSAGE) > 3){ ?>
            <div id="messages">
                <div style="" class="message-<?=$ERROR_TYPE ?>" id="main-message-<?=$ERROR_TYPE ?>">
                    <a class="dismiss-message" href="#" onclick="Effect.Fade('main-message-<?=$ERROR_TYPE ?>', { duration : 0.5 });; return false;"><img src="images/DEFAULT/_icons/16/menu.gif"></a>
                    <?=$ERROR_MESSAGE ?>
                </div>
                <script type="text/javascript" language="javascript">Effect.Pulsate('main-message-<?=$ERROR_TYPE ?>', { pulses : 2, duration : 1, from : 0.7 });</script>
            </div>
        <? } ?> 
        <ul class="form">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <ul class="form">
                        <div class="CapBody bd_padding_20">


                            <strong>ATTENTION: YOU MUST BE AT LEAST 18 YEARS OLD TO REGISTER ON OR USE THIS
                                WEBSITE. ACCESS OR USE OF THIS SITE OR ITS CONTENTS BY ANY PERSON UNDER THE AGE
                                OF 18 IS STRICTLY PROHIBITED </strong>
                            <p>These Terms are issued by <?=DB_DOMAIN ?> (the “Company”). Please
                                read this Member Terms and Conditions Agreement (the "Agreement")
                                carefully. The Agreement sets out the terms under which the Website
                                services (the "Services") are provided to you by us and applies to
                                the entire contents of the Website under the domain name <?=DB_DOMAIN ?>
                                (the “Website” ) and to any correspondence by e-mail between you
                                and us. Please read this Agreement carefully before using this Website.</p>
                            <p>By registering with Website, you become a Member (a "Member"),
                                and you agree to be bound by the terms and conditions of this Agreement (the
                                "Terms") for as long as you continue to be a Member. Visitors to the
                                Website who do not register as a member also agree to be bound by these Terms.
                                If you do not agree to the Terms, please do not register for the Website Service or otherwise access or use this Website.</p>
                            <p> <strong>1. INTRODUCTION</strong></p>
                            <hr>
                            <p> 1.1 By accessing any part of the Website, you shall be deemed to have accepted
                                the Terms in full. If you do not accept these Terms in full, you must leave
                                the Website immediately.</p>
                            <p> 1.2 You are responsible for obtaining access to the Website, and that access
                                may involve third-party fees (such as Internet service provider or airtime charges).
                                You are responsible for those fees. In addition, you must provide and are responsible
                                for all equipment necessary to access the Website.</p>
                            <p> 1.3 The Company makes no guarantee that the Website will be secure, continuously
                                accessible – without interruption or delay – and completely error
                                free 100% of the time. The Company accepts no liability or responsibility for
                                any breaches of security, interruptions or delays, or errors, which you might
                                experience on the Website other than as set out in these Terms.</p>
                            <p> 1.4 Access to the Website may be suspended temporarily and without notice
                                in the case of system failure, maintenance or repair or for reasons beyond the
                                Company’s control.</p>
                            <p> 1.5 The Company reserves the right to modify or withdraw, temporarily or permanently
                                the Website (or any part of it) with or without notice and shall not be liable
                                to you or any third party for any modification or withdrawal of the Website.</p>
                            <p> <strong>2. OUR RIGHTS </strong></p>
                            <hr>
                            <p> 2.1 We reserve the right at any time to:</p>
                            <p> 2.1.1 Change the terms and conditions of the Agreement;</p>
                            <p> 2.1.2 Change the Website, including eliminating or discontinuing any content
                                on or feature of the Website; or</p>
                            <p> 2.1.3 Change any membership fees or charges for using the Website.</p>
                            <p> 2.2. Any changes we make will be effective immediately upon notice, which
                                we may provide by means including, without limitation, posting on the Website
                                or email. Your use of the Website after such notice will be deemed acceptance
                                of the changes. Be sure to review this Agreement periodically to ensure familiarity
                                with the most current version. Upon our request, you agree to sign a non-electronic
                                version of this Agreement.</p>
                            <p> <strong>3. REGISTRATION</strong></p>
                            <hr>
                            <p> 3.1 To become a Member you must register with us. When and if you register
                                to become a Member, you agree to provide accurate, current and complete information
                                about yourself as prompted by our registration form ("Registration Data"),
                                and to maintain and update your information to keep it accurate, current and
                                complete. You agree that we may rely on your Registration Data as accurate,
                                current and complete. You acknowledge that if your Registration Data is untrue,
                                inaccurate, not current or incomplete in any respect, we reserve the right to
                                terminate this Agreement and your use of the Website.</p>
                            <p> 3.2 When you register, we will require that you provide sufficient information
                                to indicate that you are at least 18 years old. By becoming a Member, you represent
                                and warrant that you are at least 18 years old, which is the minimum required
                                age to become a Member. However, we cannot guarantee that each Member is at
                                least the required minimum age, nor do we accept responsibility or liability
                                for any content, communication or other use or access of the Website by persons
                                under the age of 18 in violation of these Terms.</p>
                            <p> 3.3 Either you or Website may terminate your Membership at any
                                time, for any reason, effective upon sending written notice to the other party.
                                All Membership fees paid are non-refundable. We reserve the right to immediately
                                suspend or terminate your access to the Service, without notice, upon any breach
                                of this Agreement by you, which is brought to our attention.</p>
                            <p> 3.4 Your Membership in the Service is for your sole, personal use. You may
                                not authorise others to use your Membership, and you may not assign or otherwise
                                transfer your account to any other person or entity</p>
                            <p> <strong>4. USERNAME AND PASSWORD. </strong></p>
                            <hr>
                            <p> 4.1 As part of the registration process, you will be asked to select a username
                                and password. We may refuse to grant any username that impersonates someone
                                else, is or may be illegal, is or may be protected by trademark or other proprietary
                                rights law, is vulgar or otherwise offensive, or may cause confusion, as we
                                determine in our sole discretion. You are responsible for the confidentiality
                                and use of your username and password and agree not to transfer or resell your
                                use of or access to the Website to any third party. If you have reason to believe
                                that your account is no longer secure, you must promptly change your password
                                by updating your account information, available at the 'MyCrowd' Page after
                                logging on to Website web-Website, and immediately notify us by
                                emailing us. YOU ARE SOLELY RESPONSIBLE FOR MAINTAINING THE CONFIDENTIALITY
                                OF YOUR USERNAME AND PASSWORD AND FOR ANY AND ALL ACTIVITIES THAT ARE CONDUCTED
                                THROUGH YOUR ACCOUNT and for restricting access to Your computer to prevent
                                unauthorised access following registration.</p>
                            <p> <strong>5. PAYMENT </strong></p>
                            <hr>
                            <p> 5.1 Our fees are as set out in our Website from time to time. Fees are due
                                in full in advance and are payable monthly unless you have opted for lifetime
                                membership where one payment is due in advance.</p>
                            <p> 5.2 Upon registering for the Services you will be sent your user registration
                                details and payment confirmation e-mail, which contains your payment reference.
                                You must keep a copy of this information as this may be required if you want
                                to cancel your FuturePay agreement.</p>
                            <p> 5.3 Once you have started using the Services you shall not be entitled to
                                any refund unless there is an error in the operation of our program or processes
                                that results in the Services being unavailable for 48 hours or more in any one
                                consecutive period . If you feel that the Services have been defective in any
                                way you must contact our Support Team using the Contact Form on the Website,
                                with your reasons for claiming a refund plus a copy of your user registration
                                details and Transaction id Number or Payment invoice (without this we will be
                                unable to help).</p>
                            <p> 5.4 Where we agree to a refund, the refund will be made within 30 days of
                                your application. If a refund is granted then this will be on a pro-rated basis
                                for how long you have used the membership. A small administration charge will
                                be deducted from the amount paid.</p>
                            <p> 5.5 In the event that:</p>
                            <p> 5.5.1 we are unable to process your payment details within three days of the
                                due date;</p>
                            <p> 5.5.2 your payment is refused; or</p>
                            <p> 5.5.3 your payment is not cleared</p>
                            <p> the Services will terminate automatically.</p>
                            <p> <strong>6. ONLINE CONDUCT </strong></p>
                            <hr>
                            <p> 6.1 As a Member, you agree that:</p>
                            <p> 6.1.1 You are solely responsible for the content or information you publish
                                or display (hereinafter, "post") on the Service, or transmit to other
                                Members.</p>
                            <p> 6.1.2 You will not post on the Service, or transmit to other Members or employees,
                                any defamatory, inaccurate, abusive, obscene, profane, offensive sexually oriented,
                                threatening, harassing, racially offensive, or illegal material, or any material
                                that infringes or violates another party's rights (including, but not limited
                                to, intellectual property rights, and rights of privacy and publicity). </p>
                            <p> 6.1.3 You will use the Service in a manner consistent with any and all applicable
                                laws and regulations. You will not include in your profile any telephone numbers,
                                street addresses, last names, URLs, email addresses, offensive references, or
                                offensive language, or any confidential information of any third person, and
                                you will not post any photographs or other images containing personal information.
                                We reserves the right, but has no obligation, to reject any profile or photograph
                                or image that does not comply with the following prohibitions:</p>
                            <p> (a) You will not impersonate any person or entity;</p>
                            <p> (b) You will not "stalk" or otherwise harass any person;</p>
                            <p> (c) You will not engage in advertising to, or solicitation of, other Members
                                to buy or sell any products or services through the Service. You will not transmit
                                any chain letters, spam or junk email to other Members;</p>
                            <p> (d) You will not express or imply that any statements you make are endorsed
                                by us, without our specific prior written consent;</p>
                            <p> (e) You will not harvest or collect personal information about other members
                                whether or not for commercial purposes, without their express consent;</p>
                            <p> (f) You will not use any robot, spider, site search/retrieval application,
                                or other manual or automatic device or process to retrieve, index, "data
                                mine", or in any way reproduce or circumvent the navigational structure
                                or presentation of the Website or its contents;</p>
                            <p> (g) You will not post, distribute or reproduce in any way any copyrighted
                                material, trademarks, or other proprietary information without obtaining the
                                prior consent of the owner of such proprietary rights;</p>
                            <p> (h) You will not remove any copyright, trademark or other proprietary rights
                                notices contained in the Website;</p>
                            <p> (i) You will not interfere with or disrupt the Services or the Website or
                                the servers or networks connected to the Services or the Website;</p>
                            <p> (j) You will not post, email or otherwise transmit any material that contains
                                software viruses or any other computer code, files or programs designed to interrupt,
                                destroy or limit the functionality of any computer software or hardware or telecommunications
                                equipment;</p>
                            <p> (k) You will not forge headers or otherwise manipulate identifiers in order
                                to disguise the origin of any information transmitted through the Service;</p>
                            <p> (l) You will not "frame" or "mirror" any part of the Website,
                                without our prior written authorization. You also shall not use metatags or
                                code or other devices containing any reference to Website or the
                                Service or the Website in order to direct any person to any other Web Website
                                for any purpose;</p>
                            <p> (m) You will not modify, adapt, sublicense, translate, sell, reverse engineer,
                                decipher, decompile or otherwise disassemble any portion of the Website or any
                                software used on or for the Website or cause others to do so;</p>
                            <p> (n) You are solely responsible for your interactions with other Members. Website reserves the right, but has no obligation, to monitor disputes
                                between you and other Members;</p>
                            <p> (o) We do not exclude any liability for death or personal injury due to our
                                negligence.</p>
                            <p> <strong>7. INDEMNITY BY MEMBER </strong></p>
                            <hr>
                            <p> 7.1 You agree to indemnify and hold harmless the Company against all claims,
                                expenses and costs (including legal costs) incurred or suffered by us as a result
                                of or in connection with (i) your breach of this Agreement; (ii) any allegation
                                that any materials that you submit to us or transmit to the Website infringe
                                or otherwise violate the copyright, trademark, trade secret or other intellectual
                                property or other rights of any third party; and/or (iii) your activities in
                                connection with the Website unless as a result of your compliance with our requirements.</p>
                            <p> <strong>8. ONLINE CONTENT </strong></p>
                            <hr>
                            <p> 8.1 Opinions, advice, statements, offers or other information or content made
                                available through the Service are those of their respective member-author and
                                not of Website, and should not be relied upon. Such Members are
                                solely responsible for such content. We do not guarantee the accuracy, completeness
                                or usefulness of any information on the Service and neither adopts nor endorses
                                nor is responsible for the accuracy or reliability of any opinion, advice or
                                statement made. Under no circumstances will Website be responsible
                                for any loss or damage resulting from anyone's reliance on information or other
                                content posted on the Service or transmitted to Members.</p>
                            <p> 8.2 The Website may contain links to other websites or resources operated
                                by parties other than the Company . The Company's inclusion of hyperlinks to
                                such websites does not imply any endorsement of the material on such websites
                                or any association with their operators . You acknowledge and agree that we
                                shall not be held responsible for the legality, accuracy or inappropriate nature
                                of any content, advertising, products, services or information located on or
                                through any other websites or for the operation or policies of any such websites,
                                nor for any loss or damages caused or alleged to have been caused by the use
                                of or reliance on any such Websites or such content or other information.</p>
                            <p> 8.3 Links to third party websites on this Website are provided solely for
                                your convenience. If you use these links, you leave the Website. If you decide
                                to access any of the third party websites linked to the Website, you do so entirely
                                at your own risk.</p>
                            <p> <strong>9. WARNING - PLEASE READ: </strong></p>
                            <hr>
                            <p> 9.1 It is possible that other Members or users (including unauthorized users,
                                or "hackers") may post or transmit offensive or obscene materials
                                on the Service and that you may be involuntarily exposed to such offensive and
                                obscene materials. It is also possible for others to obtain personal information
                                about you due to your use of the Service, and that the recipient may use such
                                information to harass or injure you. Website is not responsible
                                for the use of any personal information that you may disclose on the Service.
                                Please carefully select the type of information that you post on the Service
                                or release to others.</p>
                            <p> 9.2 Website reserves the right, but has no obligation, to monitor
                                the materials posted in any area of the Service. Website shall
                                have the right but not the obligation to remove any such material that violates,
                                or is alleged to violate, the law or this Agreement. Notwithstanding this right
                                of Website, you remain solely responsible for the content of the
                                materials you post in any area of the Service and your private email messages.
                                Emails sent between you and other members that are not readily accessible to
                                the general public will be treated as private by Website to the
                                extent required by applicable law and pursuant to the commercially reasonable
                                efforts of Website.</p>
                            <p> <strong>10. PROPRIETARY RIGHTS </strong></p>
                            <hr>
                            <p> 10.1 The Website, its design, layout, look, appearance and graphics and any
                                necessary software used in connection with the Services and the Website is the
                                exclusive property of the Company.</p>
                            <p> 10.2 Any content contained in sponsor advertisements or any information presented
                                to you through the Website is protected by copyright, trademarks, service marks,
                                patents or other proprietary rights.</p>
                            <p> 10.3 Unless otherwise stated, the copyright and other intellectual property
                                rights in all material on the Website are owned by [or licensed to the Company].
                                In addition, other Members may post copyrighted information, which has copyright
                                protection whether or not it is identified as copyrighted. Except for that information
                                which is in the public domain or for which you have been given permission, you
                                will not copy, modify, publish, transmit, distribute, perform, display or sell
                                any such proprietary information.</p>
                            <p> 10.4 By posting information or content to any area of Website,
                                you automatically grant, and you represent and warrant that you have the right
                                to grant, to Website and other Members an irrevocable, perpetual,
                                non-exclusive, fully-paid, worldwide license to use, copy, perform, display
                                and distribute such information and content and to prepare derivative works
                                of, or incorporate into other works, such information and content, and to grant
                                and authorize sublicenses of the foregoing.</p>
                            <p> <strong>COPYRIGHT POLICY </strong></p>
                            <hr>
                            <p> 10.6 We respect the intellectual property of others, and we ask our Members
                                to do the same. If you believe that a copy of your work is available on the
                                Website without your consent or that a copyright infringement has otherwise
                                occurred, please supply us with the following information:</p>
                            <p> 10.6.1 A description of the copyrighted work that you claim has been infringed;</p>
                            <p> 10.6.2 Details of where the infringing material is located on the Website;</p>
                            <p> 10.6.3 Your address, telephone number and email address;</p>
                            <p> 10.6.4 A statement by you that you believe in good faith that the use of the
                                work on the Website is not authorized by the copyright owner or any person entitled
                                to act on their behalf or by law; and</p>
                            <p> 10.6.5 An affidavit executed by you that the information you provide concerning
                                the copyright infringed is accurate and that you are the copyright owner authorized
                                to act on their behalf.</p>
                            <p> <strong>11. INFORMATION SUPPLIED BY MEMBER </strong></p>
                            <hr>
                            <p> 11.1 We will respect your personal information and undertake to comply with
                                all applicable data protection legislation in the UK and other jurisdictions
                                in which we offer the Service, subject to the Privacy Policy of Website.</p>
                            <p> 11.2 The personal information (including sensitive personal information) you
                                provide to us will be stored on computer. You consent to us using this information
                                to build up a profile of interests, preferences and browsing patterns and to
                                allow you to participate in the Website Service. All Members also
                                agree to uphold and maintain our Privacy Policy and to the terms and conditions
                                thereof.</p>
                            <p> <strong>12. DISCLAIMER OF WARRANTY </strong></p>
                            <hr>
                            <p> 12.1 By entering the Website you agree that under no circumstance will the
                                Company or its agents, officers or employees be held liable or responsible for:
                                any content contained on or omitted from the Website; any person’s reliance
                                on any such content, whether or not the content is complete, current or correct;
                                any viruses or defects that may be found to exist on the Website.</p>
                            <p> 12.2 The Company will not be liable or responsible for any damage or loss
                                caused as a result of your doing, or not doing, anything as a result of reading,
                                viewing or listening to any material, or any part of it, on the Website.</p>
                            <p> 12.3 The Company is not liable or responsible for any inaccuracies, errors
                                (including typographical errors) or omissions, or for the results obtained from
                                the use of the Website or its content. Website PROVIDES THE SERVICE
                                AND THE SITE ON AN "AS IS" BASIS AND GRANTS NO WARRANTIES OF ANY KIND,
                                EXPRESS, IMPLIED OR STATUTORY, IN ANY COMMUNICATION WITH Website
                                OR ITS REPRESENTATIVES, OR OTHERWISE WITH RESPECT TO THE SERVICE OR THE SITE.
                                Website SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTIES OF MERCHANTABILITY,
                                FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. Website
                                DISCLAIMS LIABILITY FOR, AND NO WARRANTY IS MADE WITH RESPECT TO, TELEPHONE
                                OR OTHER SERVICE, INCLUDING COVERAGE, RANGE, OR ANY INTERRUPTION IN TELEPHONE
                                OR OTHER SERVICE.</p>
                            <p> 12.4 The views expressed on the Website do not necessarily reflect the views
                                of the Company. All content, and any advice received via the Website, are not
                                intended, and should not be relied upon, for any personal, professional, legal,
                                or religious decisions you may wish to make. Instead you should consult an appropriate
                                professional in order to obtain specific advice tailored to your situation.</p>
                            <p> 12.5 Material on the Website may be susceptible to data corruption, interception
                                and unauthorised amendment for which the Company does not accept liability or
                                responsibility. The Company does not accept liability or responsibility for
                                the presence of any computer viruses contained in any material on the Website,
                                whether it is read, viewed, listened to, copied, downloaded, printed or accessed
                                in any other way. The Company does not accept liability or responsibility for
                                any losses caused as a result of any computer viruses contained in any material
                                on the Website.</p>
                            <p> 12.6 Advertisements (including banner adverts and pop-ups) featured on the
                                Website do not imply endorsement of the services or products advertised. The
                                Company will not be liable or responsible for services or products advertised
                                nor will the Company be liable or responsible for any damage to your computer
                                equipment, software, data or other property as the result of your viewing, or
                                responding to, advertisements (including banner adverts and pop-ups) featured
                                on the Website.</p>
                            <p> 12.7 The Company does not guarantee that the Website will be compatible with
                                all hardware and software that may be used by you. The Company will not be held
                                liable or responsible for any damage to your computer equipment, software, data
                                or other property as the result of your access to, use of, or browsing of any
                                material on the Website.</p>
                            <p> 12.8 If your use of material on the Website results in the need for servicing,
                                repair or correction of equipment, software or data, you shall be responsible
                                for all costs thereof.</p>
                            <p> 12.9 Nothing in these Terms shall exclude any liability of the Company, which
                                cannot be excluded or limited under applicable law.</p>
                            <p> 12.10 Subject to Clause 11.9 you enter the Website entirely at your own risk
                                and if you are dissatisfied with any portion of the Website, or with any of
                                these Terms of use, your sole and exclusive remedy is to discontinue using the
                                Website.</p>
                            <p> <strong>13. LIMITATION OF LIABILITY</strong></p>
                            <hr>
                            <p> 13.1 Website NOT BE LIABLE TO YOU FOR ANY indirect or consequential
                                loss, damage or expenses (including loss of profits, business or goodwill) INCLUDING,
                                BUT NOT LIMITED TO, DAMAGES FOR LOSS OF DATA, LOSS OF PROGRAMS, COST OF PROCUREMENT
                                OF SUBSTITUTE SERVICES OR SERVICE INTERRUPTIONS ARISING OUT OF THE USE OF OR
                                INABILITY TO USE THE SERVICE OR THE WEBSITE and we shall have no liability to
                                pay any money to you by way of compensation other than to refund you the amount
                                paid by you for the SERVICES.</p>
                            <p> 13.2 In addition, Website disclaims all liability, regardless
                                of the form of action, for the acts or omissions of other Members or users (including
                                unauthorized users, or "hackers") of the Service.</p>
                            <p> 13.3 Certain jurisdictions limit the applicability of warranty disclaimers
                                and limitations of liability so the above disclaimers of warranty and limitations
                                of liability may not apply to you.</p>
                            <p> 13.4 We shall have no liability to you for any failure to provide the Services
                                to you if caused by any event or circumstances beyond our reasonable control
                                including, without limitation, strikes, lockouts and other industrial disputes,
                                breakdown or systems or network access, flood, fire, explosion or accident.</p>
                            <p> 13.5 Although we have limited our liability in this Clause 12 nothing in these
                                Terms limits our liability for death or personal injury caused by our negligence
                                and nothing affects your legal rights.</p>
                            <p> <strong>14. COMPLAINTS</strong></p>
                            <hr>
                            <p> 14.1 To resolve a complaint regarding the Service or the Website, you should
                                contact Website Customer Support using the Contact for on the
                                Website</p>
                            <p> <strong>15. INVALIDITY</strong></p>
                            <hr>
                            <p> 15.1 If any part of this Agreement is unenforceable including any provision
                                in which we exclude our liability to you the enforceability of any other part
                                of these conditions will not be affected.</p>
                            <p> <strong>16. PRIVACY</strong></p>
                            <hr>
                            <p> 16.1 You acknowledge and agree to be bound by the terms of our privacy policy
                                and Website terms and conditions.</p>
                            <p> <strong>17. GENERAL PROVISIONS</strong></p>
                            <hr>
                            <p> 17.1 The Company may assign the Agreement or subcontract any or all of its
                                rights and obligations under the Agreement. You may not assign, transfer, charge
                                or deal in any other manner with the Agreement or any of its rights under it
                                without the prior written consent of Website .</p>
                            <p> 17.2 The Agreement shall terminate immediately and without notice if you breach
                                any of the Terms, subject to the survival of all rights and reservations of
                                Website.</p>
                            <p> 17.3 A person who is not a party to this agreement has no right under Contracts
                                (Rights of Third Parties) Act 1999 to enforce any term of this agreement but
                                this does not affect any right or remedy of a third party which exists or is
                                available apart from that Act</p>
                            <p> 17.4 The contract between us shall be governed and interpreted in accordance
                                with English law and the English Courts shall have jurisdiction to resolve any
                                disputes between us.</p>
                            <p> 17.5 These Terms together with our current website prices, contact details
                                and privacy policy set out the whole of our agreement relating to the supply
                                of the goods to you by us. Nothing said by any sales person on our behalf should
                                be understood as a variation of these terms and conditions or as an authorised
                                representation about the nature or quality of any goods offered for sale by
                                us. Save for fraud or fraudulent misrepresentation we shall have no liability
                                for any such representation being untrue or misleading.</p>
                            <p> 17.6 Unless otherwise explicitly stated, the Terms will survive termination
                                of your Membership to the Service.</p>
                            <p> 17.7 If any part of these terms and conditions are unenforceable including
                                any provision in which we exclude our liability to you the enforceability of
                                any other part of these conditions will not be affected.</p>
                            <p> 17.8 The Member certifies that the Member has read and agrees to be bound
                                by these Website Member Terms and Conditions.</p>
                            <p></p>

                        </div>
                    </ul>
                </div>
            </div>
        </ul>
        <?php
        /* MAIN CLOSE */
        if(!isset($HEADER_SINGLE_COLUMN)){ ?></div><div class="clear"></div> <? }else{ print "</div>"; }
?>

</div> <div id="main_wrapper_bottom" style="display: block !important;"></div>
</div>

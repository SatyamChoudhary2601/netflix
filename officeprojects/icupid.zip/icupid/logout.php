<?
require_once(	dirname(__FILE__)."/config.php");

session_start();
GLOBAL $DB;
$DB->Insert("DELETE FROM members_online WHERE logid= ('".$_SESSION['uid']."')");
$DB->Insert("UPDATE members SET video_live ='no' WHERE id= ('".$_SESSION['uid']."')");

session_unset();
session_destroy();

if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        setcookie($name, '', time()-3600);
        setcookie($name, '', time()-3600, '/');
    }
}

## check for phpbb integation and logout
if(FORUM_PHPBB_ENABLED =="yes"){
    define('IN_PHPBB', true);
    $phpbb_root_path = FORUM_PHPBB_ROOTPATH;
    $phpEx = substr(strrchr(__FILE__, '.'), 1);
    if(file_exists($phpbb_root_path . 'common.' . $phpEx)){
        include($phpbb_root_path . 'common.' . $phpEx);
        $user->session_begin();
        $auth->acl($user->data);
        $user->setup();
        if($user->data['is_registered']){	$user->session_kill();	$user->session_begin();	}
    }
}
## DIRECT USER TO THE HOME PAGE
header("location: ".DB_DOMAIN."index.php");
?>